#!/bin/bash

# Build script for Block-FastNMS TensorRT Plugin

set -e

echo "Building Block-FastNMS TensorRT Plugin..."
echo "=========================================="

# Create build directory
if [ ! -d "build" ]; then
    mkdir -p build
fi

cd build

# Run CMake
cmake -DCMAKE_BUILD_TYPE=Release ..

# Build
make -j$(nproc)

echo ""
echo "Build completed successfully!"
echo "Plugin library: $(pwd)/libblocknms_plugin.so"
echo "Test executable: $(pwd)/test_inference"
