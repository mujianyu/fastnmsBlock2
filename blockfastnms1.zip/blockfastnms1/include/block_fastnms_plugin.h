#pragma once

#include <NvInfer.h>
#include <cuda_runtime.h>
#include <vector>
#include <string>

namespace nvinfer1 {
namespace plugin {

constexpr const char* BLOCK_FASTNMS_PLUGIN_NAME = "BlockFastNMS";
constexpr const char* BLOCK_FASTNMS_PLUGIN_VERSION = "1.0";

}  // namespace plugin
}  // namespace nvinfer1

// Kernel function declarations (C-style for CUDA)
extern "C" {

void blockFastNmsKernel(
    cudaStream_t stream,
    const int batch_size,
    const int num_boxes,
    const int num_classes,
    const float score_threshold,
    const float iou_threshold,
    const int max_output_boxes,
    const int block_size,
    const int overlap_extension,
    const float* input_data,        // [B, 84, 8400]
    int* output_count,              // [B, 1]
    int* output_indices,            // [B, max_output_boxes]
    float* output_boxes,            // [B, max_output_boxes, 4]
    int* output_classes,            // [B, max_output_boxes]
    float* output_scores            // [B, max_output_boxes]
);

}  // extern "C"

namespace nvinfer1 {
namespace plugin {

// Plugin class
class BlockFastNMSPlugin : public nvinfer1::IPluginV2DynamicExt {
public:
    BlockFastNMSPlugin(const std::string& name,
                      float score_threshold = 0.25f,
                      float iou_threshold = 0.7f,
                      int max_output_boxes = 1000,
                      int block_size = 80,
                      int overlap_extension = 8);

    BlockFastNMSPlugin(const std::string& name, const void* data, size_t length);

    ~BlockFastNMSPlugin() override = default;

    // IPluginV2Ext methods
    int getNbOutputs() const noexcept override;
    const char* getPluginType() const noexcept override;
    const char* getPluginVersion() const noexcept override;
    nvinfer1::IPluginV2DynamicExt* clone() const noexcept override;
    nvinfer1::DimsExprs getOutputDimensions(int output_index,
                                           const nvinfer1::DimsExprs* inputs,
                                           int nb_inputs,
                                           nvinfer1::IExprBuilder& expr_builder) noexcept override;

    bool supportsFormatCombination(int pos,
                                  const nvinfer1::PluginTensorDesc* in_out,
                                  int nb_inputs,
                                  int nb_outputs) noexcept override;

    void configurePlugin(const nvinfer1::DynamicPluginTensorDesc* in,
                        int nb_inputs,
                        const nvinfer1::DynamicPluginTensorDesc* out,
                        int nb_outputs) noexcept override;

    size_t getWorkspaceSize(const nvinfer1::PluginTensorDesc* inputs,
                           int nb_inputs,
                           const nvinfer1::PluginTensorDesc* outputs,
                           int nb_outputs) const noexcept override;

    int enqueue(const nvinfer1::PluginTensorDesc* input_desc,
               const nvinfer1::PluginTensorDesc* output_desc,
               const void* const* inputs,
               void* const* outputs,
               void* workspace,
               cudaStream_t stream) noexcept override;

    void destroy() noexcept override;
    const char* getPluginNamespace() const noexcept override;
    void setPluginNamespace(const char* libNamespace) noexcept override;
    size_t getSerializationSize() const noexcept override;
    void serialize(void* buffer) const noexcept override;

    // IPluginV2 methods
    DataType getOutputDataType(int index, const nvinfer1::DataType* input_types, int nb_inputs) const noexcept override;
    
    // IPluginV2 methods
    int32_t initialize() noexcept override { return 0; }
    void terminate() noexcept override {}
    void attachToContext(cudnnContext* cudnnContext, cublasContext* cublasContext, IGpuAllocator* gpuAllocator) noexcept override;
    void detachFromContext() noexcept override;

private:
    std::string mNamespace;
    std::string mPluginName;
    
    float mScoreThreshold;
    float mIouThreshold;
    int mMaxOutputBoxes;
    int mBlockSize;
    int mOverlapExtension;

    int mBatchSize;
    int mNumBoxes;
    int mNumClasses;
};

// Plugin creator
class BlockFastNMSPluginCreator : public nvinfer1::IPluginCreator {
public:
    BlockFastNMSPluginCreator();
    ~BlockFastNMSPluginCreator() override = default;

    const char* getPluginName() const noexcept override;
    const char* getPluginVersion() const noexcept override;
    const nvinfer1::PluginFieldCollection* getFieldNames() noexcept override;
    nvinfer1::IPluginV2DynamicExt* createPlugin(const char* name,
                                               const nvinfer1::PluginFieldCollection* fc) noexcept override;
    nvinfer1::IPluginV2DynamicExt* deserializePlugin(const char* name,
                                                    const void* data,
                                                    size_t length) noexcept override;
    void setPluginNamespace(const char* libNamespace) noexcept override;
    const char* getPluginNamespace() const noexcept override;

private:
    std::vector<nvinfer1::PluginField> mPluginAttributes;
    nvinfer1::PluginFieldCollection mFC;
    std::string mNamespace;
};

}  // namespace plugin
}  // namespace nvinfer1
