#include "block_fastnms_plugin.h"
#include <cuda_runtime.h>
#include <cstring>
#include <iostream>
#include <algorithm>

namespace nvinfer1 {
namespace plugin {

BlockFastNMSPlugin::BlockFastNMSPlugin(
    const std::string& name,
    float score_threshold,
    float iou_threshold,
    int max_output_boxes,
    int block_size,
    int overlap_extension)
    : mPluginName(name),
      mScoreThreshold(score_threshold),
      mIouThreshold(iou_threshold),
      mMaxOutputBoxes(max_output_boxes),
      mBlockSize(block_size),
      mOverlapExtension(overlap_extension),
      mBatchSize(1),
      mNumBoxes(8400),
      mNumClasses(80) {}

BlockFastNMSPlugin::BlockFastNMSPlugin(
    const std::string& name,
    const void* data,
    size_t length)
    : mPluginName(name) {
    const char* buf = reinterpret_cast<const char*>(data);
    std::memcpy(&mScoreThreshold, buf, sizeof(float));
    buf += sizeof(float);
    std::memcpy(&mIouThreshold, buf, sizeof(float));
    buf += sizeof(float);
    std::memcpy(&mMaxOutputBoxes, buf, sizeof(int));
    buf += sizeof(int);
    std::memcpy(&mBlockSize, buf, sizeof(int));
    buf += sizeof(int);
    std::memcpy(&mOverlapExtension, buf, sizeof(int));
    buf += sizeof(int);
    std::memcpy(&mBatchSize, buf, sizeof(int));
    buf += sizeof(int);
    std::memcpy(&mNumBoxes, buf, sizeof(int));
    buf += sizeof(int);
    std::memcpy(&mNumClasses, buf, sizeof(int));
}

int BlockFastNMSPlugin::getNbOutputs() const noexcept {
    return 3;  // boxes, scores, indices
}

const char* BlockFastNMSPlugin::getPluginType() const noexcept {
    return BLOCK_FASTNMS_PLUGIN_NAME;
}

const char* BlockFastNMSPlugin::getPluginVersion() const noexcept {
    return BLOCK_FASTNMS_PLUGIN_VERSION;
}

IPluginV2DynamicExt* BlockFastNMSPlugin::clone() const noexcept {
    return new BlockFastNMSPlugin(*this);
}

DimsExprs BlockFastNMSPlugin::getOutputDimensions(
    int output_index,
    const DimsExprs* inputs,
    int nb_inputs,
    IExprBuilder& expr_builder) noexcept {
    
    DimsExprs output;
    
    if (output_index == 0) {  // boxes: [B, M, 4]
        output.nbDims = 3;
        output.d[0] = inputs[0].d[0];  // batch size
        output.d[1] = expr_builder.constant(mMaxOutputBoxes);
        output.d[2] = expr_builder.constant(4);
    } else if (output_index == 1) {  // scores: [B, M]
        output.nbDims = 2;
        output.d[0] = inputs[0].d[0];  // batch size
        output.d[1] = expr_builder.constant(mMaxOutputBoxes);
    } else {  // indices: [B, M]
        output.nbDims = 2;
        output.d[0] = inputs[0].d[0];  // batch size
        output.d[1] = expr_builder.constant(mMaxOutputBoxes);
    }
    
    return output;
}

bool BlockFastNMSPlugin::supportsFormatCombination(
    int pos,
    const PluginTensorDesc* in_out,
    int nb_inputs,
    int nb_outputs) noexcept {
    
    if (pos < nb_inputs) {
        // Input must be float32
        return in_out[pos].type == DataType::kFLOAT &&
               in_out[pos].format == TensorFormat::kLINEAR;
    } else {
        // Outputs: boxes and scores are float, indices are int
        if (pos == nb_inputs) {  // boxes
            return in_out[pos].type == DataType::kFLOAT &&
                   in_out[pos].format == TensorFormat::kLINEAR;
        } else if (pos == nb_inputs + 1) {  // scores
            return in_out[pos].type == DataType::kFLOAT &&
                   in_out[pos].format == TensorFormat::kLINEAR;
        } else {  // indices
            return in_out[pos].type == DataType::kINT32 &&
                   in_out[pos].format == TensorFormat::kLINEAR;
        }
    }
}

void BlockFastNMSPlugin::configurePlugin(
    const DynamicPluginTensorDesc* in,
    int nb_inputs,
    const DynamicPluginTensorDesc* out,
    int nb_outputs) noexcept {
    
    mBatchSize = in[0].desc.dims.d[0];
    mNumBoxes = in[0].desc.dims.d[2];
}

size_t BlockFastNMSPlugin::getWorkspaceSize(
    const PluginTensorDesc* inputs,
    int nb_inputs,
    const PluginTensorDesc* outputs,
    int nb_outputs) const noexcept {
    
    // Workspace for intermediate results
    size_t size = 0;
    size += mBatchSize * mNumBoxes * sizeof(int);    // sorted indices
    size += mBatchSize * mNumBoxes * sizeof(float);  // sorted scores
    size += mBatchSize * mNumBoxes * sizeof(int);    // sorted classes
    size += mBatchSize * sizeof(int);                // output counts
    return size;
}

int BlockFastNMSPlugin::enqueue(
    const PluginTensorDesc* input_desc,
    const PluginTensorDesc* output_desc,
    const void* const* inputs,
    void* const* outputs,
    void* workspace,
    cudaStream_t stream) noexcept {
    
    const float* input_data = reinterpret_cast<const float*>(inputs[0]);
    
    float* output_boxes = reinterpret_cast<float*>(outputs[0]);
    float* output_scores = reinterpret_cast<float*>(outputs[1]);
    int* output_indices = reinterpret_cast<int*>(outputs[2]);
    
    // Allocate workspace
    char* ws = reinterpret_cast<char*>(workspace);
    int* d_sorted_indices = reinterpret_cast<int*>(ws);
    ws += mBatchSize * mNumBoxes * sizeof(int);
    float* d_sorted_scores = reinterpret_cast<float*>(ws);
    ws += mBatchSize * mNumBoxes * sizeof(float);
    int* d_sorted_classes = reinterpret_cast<int*>(ws);
    ws += mBatchSize * mNumBoxes * sizeof(int);
    int* d_output_count = reinterpret_cast<int*>(ws);
    
    // Initialize output count
    cudaMemsetAsync(d_output_count, 0, mBatchSize * sizeof(int), stream);
    
    // Call the kernel
    try {
        blockFastNmsKernel(
            stream,
            mBatchSize,
            mNumBoxes,
            mNumClasses,
            mScoreThreshold,
            mIouThreshold,
            mMaxOutputBoxes,
            mBlockSize,
            mOverlapExtension,
            input_data,
            d_output_count,
            output_indices,
            output_boxes,
            output_indices,  // reuse indices as classes output
            output_scores
        );
    } catch (const std::exception& e) {
        std::cerr << "Error in blockFastNmsKernel: " << e.what() << std::endl;
        return 1;
    }
    
    return 0;
}

void BlockFastNMSPlugin::destroy() noexcept {
    delete this;
}

const char* BlockFastNMSPlugin::getPluginNamespace() const noexcept {
    return mNamespace.c_str();
}

void BlockFastNMSPlugin::setPluginNamespace(const char* libNamespace) noexcept {
    mNamespace = libNamespace;
}

size_t BlockFastNMSPlugin::getSerializationSize() const noexcept {
    return sizeof(float) * 2 + sizeof(int) * 6;
}

void BlockFastNMSPlugin::serialize(void* buffer) const noexcept {
    char* buf = reinterpret_cast<char*>(buffer);
    std::memcpy(buf, &mScoreThreshold, sizeof(float));
    buf += sizeof(float);
    std::memcpy(buf, &mIouThreshold, sizeof(float));
    buf += sizeof(float);
    std::memcpy(buf, &mMaxOutputBoxes, sizeof(int));
    buf += sizeof(int);
    std::memcpy(buf, &mBlockSize, sizeof(int));
    buf += sizeof(int);
    std::memcpy(buf, &mOverlapExtension, sizeof(int));
    buf += sizeof(int);
    std::memcpy(buf, &mBatchSize, sizeof(int));
    buf += sizeof(int);
    std::memcpy(buf, &mNumBoxes, sizeof(int));
    buf += sizeof(int);
    std::memcpy(buf, &mNumClasses, sizeof(int));
}

DataType BlockFastNMSPlugin::getOutputDataType(
    int index,
    const DataType* input_types,
    int nb_inputs) const noexcept {
    
    if (index < 2) {  // boxes and scores
        return DataType::kFLOAT;
    } else {  // indices
        return DataType::kINT32;
    }
}

void BlockFastNMSPlugin::attachToContext(
    cudnnContext* cudnnContext,
    cublasContext* cublasContext,
    IGpuAllocator* gpuAllocator) noexcept {
}

void BlockFastNMSPlugin::detachFromContext() noexcept {
}

// Plugin Creator implementation
BlockFastNMSPluginCreator::BlockFastNMSPluginCreator() {
    mPluginAttributes.emplace_back(PluginField("score_threshold", nullptr, PluginFieldType::kFLOAT32, 1));
    mPluginAttributes.emplace_back(PluginField("iou_threshold", nullptr, PluginFieldType::kFLOAT32, 1));
    mPluginAttributes.emplace_back(PluginField("max_output_boxes", nullptr, PluginFieldType::kINT32, 1));
    mPluginAttributes.emplace_back(PluginField("block_size", nullptr, PluginFieldType::kINT32, 1));
    mPluginAttributes.emplace_back(PluginField("overlap_extension", nullptr, PluginFieldType::kINT32, 1));
    
    mFC.nbFields = mPluginAttributes.size();
    mFC.fields = mPluginAttributes.data();
}

const char* BlockFastNMSPluginCreator::getPluginName() const noexcept {
    return BLOCK_FASTNMS_PLUGIN_NAME;
}

const char* BlockFastNMSPluginCreator::getPluginVersion() const noexcept {
    return BLOCK_FASTNMS_PLUGIN_VERSION;
}

const PluginFieldCollection* BlockFastNMSPluginCreator::getFieldNames() noexcept {
    return &mFC;
}

IPluginV2DynamicExt* BlockFastNMSPluginCreator::createPlugin(
    const char* name,
    const PluginFieldCollection* fc) noexcept {
    
    float score_threshold = 0.25f;
    float iou_threshold = 0.7f;
    int max_output_boxes = 1000;
    int block_size = 80;
    int overlap_extension = 8;
    
    const PluginField* fields = fc->fields;
    for (int i = 0; i < fc->nbFields; i++) {
        const char* attr_name = fields[i].name;
        if (std::strcmp(attr_name, "score_threshold") == 0) {
            score_threshold = *(static_cast<const float*>(fields[i].data));
        } else if (std::strcmp(attr_name, "iou_threshold") == 0) {
            iou_threshold = *(static_cast<const float*>(fields[i].data));
        } else if (std::strcmp(attr_name, "max_output_boxes") == 0) {
            max_output_boxes = *(static_cast<const int*>(fields[i].data));
        } else if (std::strcmp(attr_name, "block_size") == 0) {
            block_size = *(static_cast<const int*>(fields[i].data));
        } else if (std::strcmp(attr_name, "overlap_extension") == 0) {
            overlap_extension = *(static_cast<const int*>(fields[i].data));
        }
    }
    
    return new BlockFastNMSPlugin(name, score_threshold, iou_threshold,
                                 max_output_boxes, block_size, overlap_extension);
}

IPluginV2DynamicExt* BlockFastNMSPluginCreator::deserializePlugin(
    const char* name,
    const void* data,
    size_t length) noexcept {
    
    return new BlockFastNMSPlugin(name, data, length);
}

void BlockFastNMSPluginCreator::setPluginNamespace(const char* libNamespace) noexcept {
    mNamespace = libNamespace;
}

const char* BlockFastNMSPluginCreator::getPluginNamespace() const noexcept {
    return mNamespace.c_str();
}

}  // namespace plugin
}  // namespace nvinfer1

// Export plugin creator
extern "C" {
nvinfer1::plugin::BlockFastNMSPluginCreator* getCreator() {
    return new nvinfer1::plugin::BlockFastNMSPluginCreator();
}
}
