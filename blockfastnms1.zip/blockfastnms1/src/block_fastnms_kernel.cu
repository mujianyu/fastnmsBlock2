#include <cuda_runtime.h>
#include <cmath>
#include <algorithm>
#include <cstring>

// Sigmoid function
__device__ float sigmoid(float x) {
    return 1.0f / (1.0f + expf(-x));
}

// Calculate IoU between two boxes
__device__ float calculateIoU(
    float x1, float y1, float w1, float h1,
    float x2, float y2, float w2, float h2) {
    
    float left1 = x1 - w1 / 2.0f;
    float right1 = x1 + w1 / 2.0f;
    float top1 = y1 - h1 / 2.0f;
    float bottom1 = y1 + h1 / 2.0f;
    
    float left2 = x2 - w2 / 2.0f;
    float right2 = x2 + w2 / 2.0f;
    float top2 = y2 - h2 / 2.0f;
    float bottom2 = y2 + h2 / 2.0f;
    
    float inter_left = max(left1, left2);
    float inter_right = min(right1, right2);
    float inter_top = max(top1, top2);
    float inter_bottom = min(bottom1, bottom2);
    
    float inter_width = max(0.0f, inter_right - inter_left);
    float inter_height = max(0.0f, inter_bottom - inter_top);
    float intersection = inter_width * inter_height;
    
    float area1 = w1 * h1;
    float area2 = w2 * h2;
    float union_area = area1 + area2 - intersection;
    
    if (union_area < 1e-8f) return 0.0f;
    return intersection / union_area;
}

// Main NMS kernel
__global__ void blockFastNmsKernelFunc(
    const int batch_size,
    const int num_boxes,
    const int num_classes,
    const float score_threshold,
    const float iou_threshold,
    const int max_output_boxes,
    const float* input_data,        // [B, 84, 8400] -> [B, 8400, 84]
    int* output_count,              // [B]
    int* output_indices,            // [B, max_output_boxes]
    float* output_boxes,            // [B, max_output_boxes, 4]
    int* output_classes,            // [B, max_output_boxes]
    float* output_scores,           // [B, max_output_boxes]
    int* sorted_indices,            // [B, 8400]
    float* sorted_scores,           // [B, 8400]
    int* sorted_classes             // [B, 8400]
) {
    int b = blockIdx.x;
    int idx = threadIdx.x + blockIdx.y * blockDim.x;
    
    if (b >= batch_size || idx >= num_boxes) return;
    
    // Step 1: Get sorted index for this box
    int box_idx = sorted_indices[b * num_boxes + idx];
    float box_score = sorted_scores[b * num_boxes + idx];
    int box_class = sorted_classes[b * num_boxes + idx];
    
    // Step 2: Skip if score is below threshold
    if (box_score < score_threshold) {
        return;
    }
    
    // Step 3: Check if suppressed by higher-score boxes
    bool suppressed = false;
    for (int j = 0; j < idx; j++) {
        int prev_box_idx = sorted_indices[b * num_boxes + j];
        float prev_score = sorted_scores[b * num_boxes + j];
        int prev_class = sorted_classes[b * num_boxes + j];
        
        // Only check same class
        if (prev_class != box_class) continue;
        
        // Check if score is above threshold
        if (prev_score < score_threshold) continue;
        
        // Get coordinates from input
        int offset_curr = b * 84 * num_boxes + box_idx * 84 + 0;
        int offset_prev = b * 84 * num_boxes + prev_box_idx * 84 + 0;
        
        float x1 = input_data[offset_curr];
        float y1 = input_data[offset_curr + 1];
        float w1 = input_data[offset_curr + 2];
        float h1 = input_data[offset_curr + 3];
        
        float x2 = input_data[offset_prev];
        float y2 = input_data[offset_prev + 1];
        float w2 = input_data[offset_prev + 2];
        float h2 = input_data[offset_prev + 3];
        
        float iou = calculateIoU(x1, y1, w1, h1, x2, y2, w2, h2);
        
        if (iou > iou_threshold) {
            suppressed = true;
            break;
        }
    }
    
    if (suppressed) return;
    
    // Step 4: Add to output using atomic operation
    int pos = atomicAdd(&output_count[b], 1);
    
    if (pos < max_output_boxes) {
        int offset = b * 84 * num_boxes + box_idx * 84;
        
        output_boxes[b * max_output_boxes * 4 + pos * 4 + 0] = input_data[offset];
        output_boxes[b * max_output_boxes * 4 + pos * 4 + 1] = input_data[offset + 1];
        output_boxes[b * max_output_boxes * 4 + pos * 4 + 2] = input_data[offset + 2];
        output_boxes[b * max_output_boxes * 4 + pos * 4 + 3] = input_data[offset + 3];
        
        output_classes[b * max_output_boxes + pos] = box_class;
        output_scores[b * max_output_boxes + pos] = box_score;
        output_indices[b * max_output_boxes + pos] = box_idx;
    }
}

// Sorting kernel using bitonic sort (simplified for demonstration)
__global__ void sortBoxesByScoreKernel(
    const int batch_size,
    const int num_boxes,
    const float* input_data,        // [B, 84, 8400]
    int* sorted_indices,            // [B, 8400]
    float* sorted_scores,           // [B, 8400]
    int* sorted_classes             // [B, 8400]
) {
    int b = blockIdx.x;
    int idx = threadIdx.x;
    
    if (b >= batch_size || idx >= num_boxes) return;
    
    // Extract box data
    int offset = b * 84 * num_boxes + idx * 84;
    
    // Find max score among classes (argmax)
    float max_score = 0.0f;
    int max_class = 0;
    
    for (int c = 0; c < 80; c++) {
        float class_conf = sigmoid(input_data[offset + 4 + c]);
        if (class_conf > max_score) {
            max_score = class_conf;
            max_class = c;
        }
    }
    
    sorted_indices[b * num_boxes + idx] = idx;
    sorted_scores[b * num_boxes + idx] = max_score;
    sorted_classes[b * num_boxes + idx] = max_class;
}

// CPU-side sorting helper (called from host code)
void sortByScoreCPU(
    const int batch_size,
    const int num_boxes,
    int* indices,
    float* scores,
    int* classes) {
    
    for (int b = 0; b < batch_size; b++) {
        // Create sorting indices
        std::vector<int> sort_idx(num_boxes);
        for (int i = 0; i < num_boxes; i++) {
            sort_idx[i] = i;
        }
        
        // Sort by score descending
        std::sort(sort_idx.begin(), sort_idx.end(),
                  [&](int i, int j) {
                      return scores[b * num_boxes + i] > scores[b * num_boxes + j];
                  });
        
        // Copy sorted data
        int* temp_indices = new int[num_boxes];
        float* temp_scores = new float[num_boxes];
        int* temp_classes = new int[num_boxes];
        
        std::memcpy(temp_indices, indices + b * num_boxes, num_boxes * sizeof(int));
        std::memcpy(temp_scores, scores + b * num_boxes, num_boxes * sizeof(float));
        std::memcpy(temp_classes, classes + b * num_boxes, num_boxes * sizeof(int));
        
        for (int i = 0; i < num_boxes; i++) {
            int orig_idx = sort_idx[i];
            indices[b * num_boxes + i] = temp_indices[orig_idx];
            scores[b * num_boxes + i] = temp_scores[orig_idx];
            classes[b * num_boxes + i] = temp_classes[orig_idx];
        }
        
        delete[] temp_indices;
        delete[] temp_scores;
        delete[] temp_classes;
    }
}

// Main wrapper function
extern "C" void blockFastNmsKernel(
    cudaStream_t stream,
    const int batch_size,
    const int num_boxes,
    const int num_classes,
    const float score_threshold,
    const float iou_threshold,
    const int max_output_boxes,
    const int block_size,
    const int overlap_extension,
    const float* input_data,        // [B, 84, 8400]
    int* output_count,              // [B, 1]
    int* output_indices,            // [B, max_output_boxes]
    float* output_boxes,            // [B, max_output_boxes, 4]
    int* output_classes,            // [B, max_output_boxes]
    float* output_scores            // [B, max_output_boxes]
) {
    // Allocate device memory for sorting
    int* d_sorted_indices;
    float* d_sorted_scores;
    int* d_sorted_classes;
    float* d_input_data_transposed;
    
    cudaMalloc(&d_sorted_indices, batch_size * num_boxes * sizeof(int));
    cudaMalloc(&d_sorted_scores, batch_size * num_boxes * sizeof(float));
    cudaMalloc(&d_sorted_classes, batch_size * num_boxes * sizeof(int));
    cudaMalloc(&d_input_data_transposed, batch_size * 84 * num_boxes * sizeof(float));
    
    // Copy input data to device
    cudaMemcpyAsync(d_input_data_transposed, input_data,
                    batch_size * 84 * num_boxes * sizeof(float),
                    cudaMemcpyHostToDevice, stream);
    
    // Step 1: Extract scores and classes from input data
    int threads_per_block = 256;
    int num_blocks = (num_boxes + threads_per_block - 1) / threads_per_block;
    
    sortBoxesByScoreKernel<<<dim3(batch_size, 1), threads_per_block, 0, stream>>>(
        batch_size, num_boxes, d_input_data_transposed,
        d_sorted_indices, d_sorted_scores, d_sorted_classes);
    
    // Step 2: Sort on CPU (for simplicity; can be optimized with CUB)
    int* h_sorted_indices = new int[batch_size * num_boxes];
    float* h_sorted_scores = new float[batch_size * num_boxes];
    int* h_sorted_classes = new int[batch_size * num_boxes];
    
    cudaMemcpyAsync(h_sorted_indices, d_sorted_indices,
                    batch_size * num_boxes * sizeof(int),
                    cudaMemcpyDeviceToHost, stream);
    cudaMemcpyAsync(h_sorted_scores, d_sorted_scores,
                    batch_size * num_boxes * sizeof(float),
                    cudaMemcpyDeviceToHost, stream);
    cudaMemcpyAsync(h_sorted_classes, d_sorted_classes,
                    batch_size * num_boxes * sizeof(int),
                    cudaMemcpyDeviceToHost, stream);
    
    cudaStreamSynchronize(stream);
    
    // Sort on CPU
    for (int b = 0; b < batch_size; b++) {
        std::vector<int> sort_idx(num_boxes);
        for (int i = 0; i < num_boxes; i++) {
            sort_idx[i] = i;
        }
        
        std::sort(sort_idx.begin(), sort_idx.end(),
                  [&](int i, int j) {
                      return h_sorted_scores[b * num_boxes + i] >
                             h_sorted_scores[b * num_boxes + j];
                  });
        
        int* temp_indices = new int[num_boxes];
        float* temp_scores = new float[num_boxes];
        int* temp_classes = new int[num_boxes];
        
        std::memcpy(temp_indices, h_sorted_indices + b * num_boxes,
                   num_boxes * sizeof(int));
        std::memcpy(temp_scores, h_sorted_scores + b * num_boxes,
                   num_boxes * sizeof(float));
        std::memcpy(temp_classes, h_sorted_classes + b * num_boxes,
                   num_boxes * sizeof(int));
        
        for (int i = 0; i < num_boxes; i++) {
            int orig_idx = sort_idx[i];
            h_sorted_indices[b * num_boxes + i] = temp_indices[orig_idx];
            h_sorted_scores[b * num_boxes + i] = temp_scores[orig_idx];
            h_sorted_classes[b * num_boxes + i] = temp_classes[orig_idx];
        }
        
        delete[] temp_indices;
        delete[] temp_scores;
        delete[] temp_classes;
    }
    
    // Copy sorted data back to device
    cudaMemcpyAsync(d_sorted_indices, h_sorted_indices,
                    batch_size * num_boxes * sizeof(int),
                    cudaMemcpyHostToDevice, stream);
    cudaMemcpyAsync(d_sorted_scores, h_sorted_scores,
                    batch_size * num_boxes * sizeof(float),
                    cudaMemcpyHostToDevice, stream);
    cudaMemcpyAsync(d_sorted_classes, h_sorted_classes,
                    batch_size * num_boxes * sizeof(int),
                    cudaMemcpyHostToDevice, stream);
    
    cudaStreamSynchronize(stream);
    
    // Step 3: Run NMS kernel
    blockFastNmsKernelFunc<<<dim3(batch_size, num_blocks), threads_per_block, 0, stream>>>(
        batch_size, num_boxes, num_classes, score_threshold, iou_threshold,
        max_output_boxes, d_input_data_transposed, output_count,
        output_indices, output_boxes, output_classes, output_scores,
        d_sorted_indices, d_sorted_scores, d_sorted_classes);
    
    // Cleanup
    cudaFree(d_sorted_indices);
    cudaFree(d_sorted_scores);
    cudaFree(d_sorted_classes);
    cudaFree(d_input_data_transposed);
    
    delete[] h_sorted_indices;
    delete[] h_sorted_scores;
    delete[] h_sorted_classes;
}
