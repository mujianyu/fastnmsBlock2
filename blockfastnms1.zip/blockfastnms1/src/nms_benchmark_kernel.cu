#include <cuda_runtime.h>
#include <cmath>
#include <cstring>
#include <cub/cub.cuh>

// ============================================================================
// 共享的工具函数
// ============================================================================

__device__ float sigmoid(float x) {
    return 1.0f / (1.0f + expf(-x));
}

__device__ float calculateIoU(
    float x1, float y1, float w1, float h1,
    float x2, float y2, float w2, float h2) {
    
    float left1 = x1 - w1 / 2.0f;
    float right1 = x1 + w1 / 2.0f;
    float top1 = y1 - h1 / 2.0f;
    float bottom1 = y1 + h1 / 2.0f;
    
    float left2 = x2 - w2 / 2.0f;
    float right2 = x2 + w2 / 2.0f;
    float top2 = y2 - h2 / 2.0f;
    float bottom2 = y2 + h2 / 2.0f;
    
    float inter_left = max(left1, left2);
    float inter_right = min(right1, right2);
    float inter_top = max(top1, top2);
    float inter_bottom = min(bottom1, bottom2);
    
    float inter_width = max(0.0f, inter_right - inter_left);
    float inter_height = max(0.0f, inter_bottom - inter_top);
    float intersection = inter_width * inter_height;
    
    float area1 = w1 * h1;
    float area2 = w2 * h2;
    float union_area = area1 + area2 - intersection;
    
    if (union_area < 1e-8f) return 0.0f;
    return intersection / union_area;
}

// ============================================================================
// KERNEL 1: 不分块 NMS
// ============================================================================

__global__ void nonBlockNmsKernel(
    const int batch_size,
    const int num_boxes,
    const float score_threshold,
    const float iou_threshold,
    const int max_output_boxes,
    const float* input_data,
    int* output_count,
    float* output_boxes,
    int* output_classes,
    float* output_scores,
    const int* sorted_indices,
    const float* sorted_scores,
    const int* sorted_classes
) {
    int b = blockIdx.x;
    int idx = threadIdx.x + blockIdx.y * blockDim.x;
    
    if (b >= batch_size || idx >= num_boxes) return;
    
    int box_idx = sorted_indices[b * num_boxes + idx];
    float box_score = sorted_scores[b * num_boxes + idx];
    int box_class = sorted_classes[b * num_boxes + idx];
    
    if (box_score < score_threshold) return;
    
    bool suppressed = false;
    for (int j = 0; j < idx; j++) {
        int prev_box_idx = sorted_indices[b * num_boxes + j];
        float prev_score = sorted_scores[b * num_boxes + j];
        int prev_class = sorted_classes[b * num_boxes + j];
        
        if (prev_class != box_class) continue;
        if (prev_score < score_threshold) continue;
        
        int off_curr = b * 84 * num_boxes + box_idx * 84;
        int off_prev = b * 84 * num_boxes + prev_box_idx * 84;
        
        float x1 = input_data[off_curr];
        float y1 = input_data[off_curr + 1];
        float w1 = input_data[off_curr + 2];
        float h1 = input_data[off_curr + 3];
        
        float x2 = input_data[off_prev];
        float y2 = input_data[off_prev + 1];
        float w2 = input_data[off_prev + 2];
        float h2 = input_data[off_prev + 3];
        
        float iou = calculateIoU(x1, y1, w1, h1, x2, y2, w2, h2);
        
        if (iou > iou_threshold) {
            suppressed = true;
            break;
        }
    }
    
    if (suppressed) return;
    
    int pos = atomicAdd(&output_count[b], 1);
    if (pos < max_output_boxes) {
        int off = b * 84 * num_boxes + box_idx * 84;
        output_boxes[b * max_output_boxes * 4 + pos * 4 + 0] = input_data[off];
        output_boxes[b * max_output_boxes * 4 + pos * 4 + 1] = input_data[off + 1];
        output_boxes[b * max_output_boxes * 4 + pos * 4 + 2] = input_data[off + 2];
        output_boxes[b * max_output_boxes * 4 + pos * 4 + 3] = input_data[off + 3];
        output_classes[b * max_output_boxes + pos] = box_class;
        output_scores[b * max_output_boxes + pos] = box_score;
    }
}

// ============================================================================
// KERNEL 2: 分块 NMS
// ============================================================================

__global__ void blockNmsKernel(
    const int batch_size,
    const int num_boxes,
    const float score_threshold,
    const float iou_threshold,
    const int max_output_boxes,
    const int block_size,
    const int overlap_extension,
    const float* input_data,
    int* output_count,
    float* output_boxes,
    int* output_classes,
    float* output_scores,
    const int* sorted_indices,
    const float* sorted_scores,
    const int* sorted_classes
) {
    int b = blockIdx.x;
    int idx = threadIdx.x + blockIdx.y * blockDim.x;
    
    if (b >= batch_size || idx >= num_boxes) return;
    
    int box_idx = sorted_indices[b * num_boxes + idx];
    float box_score = sorted_scores[b * num_boxes + idx];
    int box_class = sorted_classes[b * num_boxes + idx];
    
    if (box_score < score_threshold) return;
    
    int current_block = idx / block_size;
    int search_start = max(0, current_block * block_size - overlap_extension);
    
    bool suppressed = false;
    for (int j = search_start; j < idx; j++) {
        int prev_box_idx = sorted_indices[b * num_boxes + j];
        float prev_score = sorted_scores[b * num_boxes + j];
        int prev_class = sorted_classes[b * num_boxes + j];
        
        if (prev_class != box_class) continue;
        if (prev_score < score_threshold) continue;
        
        int off_curr = b * 84 * num_boxes + box_idx * 84;
        int off_prev = b * 84 * num_boxes + prev_box_idx * 84;
        
        float x1 = input_data[off_curr];
        float y1 = input_data[off_curr + 1];
        float w1 = input_data[off_curr + 2];
        float h1 = input_data[off_curr + 3];
        
        float x2 = input_data[off_prev];
        float y2 = input_data[off_prev + 1];
        float w2 = input_data[off_prev + 2];
        float h2 = input_data[off_prev + 3];
        
        float iou = calculateIoU(x1, y1, w1, h1, x2, y2, w2, h2);
        
        if (iou > iou_threshold) {
            suppressed = true;
            break;
        }
    }
    
    if (suppressed) return;
    
    int pos = atomicAdd(&output_count[b], 1);
    if (pos < max_output_boxes) {
        int off = b * 84 * num_boxes + box_idx * 84;
        output_boxes[b * max_output_boxes * 4 + pos * 4 + 0] = input_data[off];
        output_boxes[b * max_output_boxes * 4 + pos * 4 + 1] = input_data[off + 1];
        output_boxes[b * max_output_boxes * 4 + pos * 4 + 2] = input_data[off + 2];
        output_boxes[b * max_output_boxes * 4 + pos * 4 + 3] = input_data[off + 3];
        output_classes[b * max_output_boxes + pos] = box_class;
        output_scores[b * max_output_boxes + pos] = box_score;
    }
}

// ============================================================================
// KERNEL 3: 评分提取
// ============================================================================

__global__ void extractScoresKernel(
    const int batch_size,
    const int num_boxes,
    const float* input_data,
    int* sorted_indices,
    float* sorted_scores,
    int* sorted_classes
) {
    int b = blockIdx.x;
    int idx = threadIdx.x + blockIdx.y * blockDim.x;
    
    if (b >= batch_size || idx >= num_boxes) return;
    
    int offset = b * 84 * num_boxes + idx * 84;
    
    float max_score = 0.0f;
    int max_class = 0;
    
    for (int c = 0; c < 80; c++) {
        float class_conf = sigmoid(input_data[offset + 4 + c]);
        if (class_conf > max_score) {
            max_score = class_conf;
            max_class = c;
        }
    }
    
    sorted_indices[b * num_boxes + idx] = idx;
    sorted_scores[b * num_boxes + idx] = max_score;
    sorted_classes[b * num_boxes + idx] = max_class;
}

// ============================================================================
// Kernel-only wrappers (no sort — pre-sorted data from CPU)
// ============================================================================

extern "C" void extractScores(
    cudaStream_t stream,
    const int batch_size,
    const int num_boxes,
    const float* d_input,
    int* d_indices,
    float* d_scores,
    int* d_classes
) {
    int threads = 256;
    int blocks = (num_boxes + threads - 1) / threads;
    extractScoresKernel<<<dim3(batch_size, blocks), threads, 0, stream>>>(
        batch_size, num_boxes, d_input, d_indices, d_scores, d_classes);
}

extern "C" void nonBlockNmsKernelOnly(
    cudaStream_t stream,
    const int batch_size,
    const int num_boxes,
    const float score_threshold,
    const float iou_threshold,
    const int max_output_boxes,
    const float* d_input,
    int* d_output_count,
    float* d_output_boxes,
    int* d_output_classes,
    float* d_output_scores,
    const int* d_sorted_indices,
    const float* d_sorted_scores,
    const int* d_sorted_classes
) {
    int threads = 256;
    int blocks = (num_boxes + threads - 1) / threads;
    nonBlockNmsKernel<<<dim3(batch_size, blocks), threads, 0, stream>>>(
        batch_size, num_boxes, score_threshold, iou_threshold,
        max_output_boxes, d_input,
        d_output_count, d_output_boxes, d_output_classes, d_output_scores,
        d_sorted_indices, d_sorted_scores, d_sorted_classes);
}

extern "C" void blockNmsKernelOnly(
    cudaStream_t stream,
    const int batch_size,
    const int num_boxes,
    const float score_threshold,
    const float iou_threshold,
    const int max_output_boxes,
    const int block_size,
    const int overlap_extension,
    const float* d_input,
    int* d_output_count,
    float* d_output_boxes,
    int* d_output_classes,
    float* d_output_scores,
    const int* d_sorted_indices,
    const float* d_sorted_scores,
    const int* d_sorted_classes
) {
    int threads = 256;
    int blocks = (num_boxes + threads - 1) / threads;
    blockNmsKernel<<<dim3(batch_size, blocks), threads, 0, stream>>>(
        batch_size, num_boxes, score_threshold, iou_threshold,
        max_output_boxes, block_size, overlap_extension, d_input,
        d_output_count, d_output_boxes, d_output_classes, d_output_scores,
        d_sorted_indices, d_sorted_scores, d_sorted_classes);
}

// ============================================================================
// KERNEL 4: Spatial 8x8 坐标分块 NMS
// ============================================================================

__global__ void spatialBlockNmsKernel(
    const int batch_size,
    const int num_boxes,
    const float score_threshold,
    const float iou_threshold,
    const int max_output_boxes,
    const int grid_x,
    const int grid_y,
    const int num_blocks,
    const int* blk_idx,
    const float* blk_sc,
    const int* blk_cls,
    const int* blk_start,
    const float* input_data,
    int* output_count,
    float* output_boxes,
    int* output_classes,
    float* output_scores
) {
    int b = blockIdx.x;
    int block = blockIdx.y;
    int local_idx = threadIdx.x;

    if (b >= batch_size || block >= num_blocks) return;

    int start = blk_start[b * (num_blocks + 1) + block];
    int end   = blk_start[b * (num_blocks + 1) + block + 1];
    int count = end - start;
    if (count == 0 || local_idx >= count) return;

    int global_pos = start + local_idx;
    int box_idx = blk_idx[b * num_boxes + global_pos];
    float box_score = blk_sc[b * num_boxes + global_pos];
    int box_class = blk_cls[b * num_boxes + global_pos];

    if (box_score < score_threshold) return;

    int off_curr = b * 84 * num_boxes + box_idx * 84;
    float x1 = input_data[off_curr];
    float y1 = input_data[off_curr + 1];
    float w1 = input_data[off_curr + 2];
    float h1 = input_data[off_curr + 3];

    int this_by = block / grid_x;
    int this_bx = block % grid_x;

    bool suppressed = false;

    // Step 1: same block, higher-score predecessors
    for (int j = start; j < global_pos && !suppressed; j++) {
        int prev_box_idx = blk_idx[b * num_boxes + j];
        int prev_class = blk_cls[b * num_boxes + j];
        float prev_score = blk_sc[b * num_boxes + j];
        if (prev_class != box_class) continue;
        if (prev_score < score_threshold) continue;

        int off_prev = b * 84 * num_boxes + prev_box_idx * 84;
        float x2 = input_data[off_prev];
        float y2 = input_data[off_prev + 1];
        float w2 = input_data[off_prev + 2];
        float h2 = input_data[off_prev + 3];

        if (calculateIoU(x1, y1, w1, h1, x2, y2, w2, h2) > iou_threshold)
            suppressed = true;
    }

    // Step 2: 8-neighbor blocks (all boxes)
    for (int dy = -1; dy <= 1 && !suppressed; dy++) {
        for (int dx = -1; dx <= 1 && !suppressed; dx++) {
            if (dx == 0 && dy == 0) continue;
            int nbx = this_bx + dx;
            int nby = this_by + dy;
            if (nbx < 0 || nbx >= grid_x || nby < 0 || nby >= grid_y) continue;

            int nb = nby * grid_x + nbx;
            int nb_start = blk_start[b * (num_blocks + 1) + nb];
            int nb_end   = blk_start[b * (num_blocks + 1) + nb + 1];

            for (int j = nb_start; j < nb_end && !suppressed; j++) {
                int prev_box_idx = blk_idx[b * num_boxes + j];
                int prev_class = blk_cls[b * num_boxes + j];
                float prev_score = blk_sc[b * num_boxes + j];
                if (prev_class != box_class) continue;
                if (prev_score < score_threshold) continue;

                int off_prev = b * 84 * num_boxes + prev_box_idx * 84;
                float x2 = input_data[off_prev];
                float y2 = input_data[off_prev + 1];
                float w2 = input_data[off_prev + 2];
                float h2 = input_data[off_prev + 3];

                if (calculateIoU(x1, y1, w1, h1, x2, y2, w2, h2) > iou_threshold)
                    suppressed = true;
            }
        }
    }

    if (suppressed) return;

    int pos = atomicAdd(&output_count[b], 1);
    if (pos < max_output_boxes) {
        output_boxes[b * max_output_boxes * 4 + pos * 4 + 0] = x1;
        output_boxes[b * max_output_boxes * 4 + pos * 4 + 1] = y1;
        output_boxes[b * max_output_boxes * 4 + pos * 4 + 2] = w1;
        output_boxes[b * max_output_boxes * 4 + pos * 4 + 3] = h1;
        output_classes[b * max_output_boxes + pos] = box_class;
        output_scores[b * max_output_boxes + pos] = box_score;
    }
}

extern "C" void spatialBlockNmsKernelOnly(
    cudaStream_t stream,
    const int batch_size,
    const int num_boxes,
    const float image_size,
    const float overlap_pixels,
    const float score_threshold,
    const float iou_threshold,
    const int max_output_boxes,
    const int grid_x,
    const int grid_y,
    const float* d_input,
    int* d_output_count,
    float* d_output_boxes,
    int* d_output_classes,
    float* d_output_scores,
    const int* d_blk_idx,
    const float* d_blk_sc,
    const int* d_blk_cls,
    const int* d_blk_start
) {
    int num_blocks = grid_x * grid_y;
    int threads = 256;
    spatialBlockNmsKernel<<<dim3(batch_size, num_blocks), threads, 0, stream>>>(
        batch_size, num_boxes, score_threshold, iou_threshold,
        max_output_boxes, grid_x, grid_y, num_blocks,
        d_blk_idx, d_blk_sc, d_blk_cls, d_blk_start,
        d_input,
        d_output_count, d_output_boxes, d_output_classes, d_output_scores);
}

// ============================================================================
// GPU Sort Kernels (Full pipeline: extract + sort/block + NMS)
// ============================================================================

// 全局排序后重排到 sorted_* 缓冲区
__global__ void globalSortReorderKernel(
    const int num_boxes,
    const int* d_order,
    const int* d_indices,
    const float* d_scores,
    const int* d_classes,
    int* sorted_idx,
    float* sorted_sc,
    int* sorted_cls
) {
    int i = threadIdx.x + blockIdx.x * blockDim.x;
    if (i >= num_boxes) return;
    int src = d_order[i];
    sorted_idx[i] = d_indices[src];
    sorted_sc[i]  = d_scores[src];
    sorted_cls[i] = d_classes[src];
}

// 块内 local sort (shared-memory selection sort, 每块独立降序)
__global__ void blockLocalSortKernel(
    const int num_boxes,
    const int block_size,
    const int* d_indices,
    const float* d_scores,
    const int* d_classes,
    int* sorted_idx,
    float* sorted_sc,
    int* sorted_cls
) {
    int blk = blockIdx.x;
    int tid = threadIdx.x;
    int start = blk * block_size;
    int end   = min(start + block_size, num_boxes);
    int count = end - start;
    if (count <= 0) return;

    __shared__ float sh_sc[256];
    __shared__ int   sh_idx[256];
    __shared__ int   sh_cls[256];

    if (tid < count) {
        sh_idx[tid] = d_indices[start + tid];
        sh_sc[tid]  = d_scores[start + tid];
        sh_cls[tid] = d_classes[start + tid];
    }
    __syncthreads();

    // 选择排序 (count <= 256, 块内线程数 = 256)
    for (int i = 0; i < count; i++) {
        int best = i;
        float best_sc = sh_sc[i];
        for (int j = i + 1; j < count; j++) {
            if (sh_sc[j] > best_sc) {
                best_sc = sh_sc[j];
                best = j;
            }
        }
        if (best != i) {
            float tmp_f = sh_sc[i]; sh_sc[i] = sh_sc[best]; sh_sc[best] = tmp_f;
            int tmp_i = sh_idx[i]; sh_idx[i] = sh_idx[best]; sh_idx[best] = tmp_i;
            tmp_i = sh_cls[i]; sh_cls[i] = sh_cls[best]; sh_cls[best] = tmp_i;
        }
        __syncthreads();
    }

    if (tid < count) {
        sorted_idx[start + tid] = sh_idx[tid];
        sorted_sc[start + tid]  = sh_sc[tid];
        sorted_cls[start + tid] = sh_cls[tid];
    }
}

// Spatial block: 计算每个 box 的 sort_key = block_id * 1e6 + (1 - score)
// 按 key 升序排序后得到: 先按 block_id, 再按 score 降序
__global__ void spatialAssignSortKeyKernel(
    int num_boxes,
    int grid_x,
    int grid_y,
    const float* d_input,
    const float* d_ext_scores,     // [num_boxes] extracted scores
    int* d_sort_val,               // [num_boxes] value: original index
    float* d_sort_key              // [num_boxes] key: block_id*1e6 + (1-score)
) {
    int i = threadIdx.x + blockIdx.x * blockDim.x;
    if (i >= num_boxes) return;

    float cx = d_input[i * 84 + 0];
    float cy = d_input[i * 84 + 1];

    float block_w = 1.0f / grid_x;
    float block_h = 1.0f / grid_y;
    int bx = min(grid_x - 1, max(0, (int)(cx / block_w)));
    int by = min(grid_y - 1, max(0, (int)(cy / block_h)));
    int block_id = by * grid_x + bx;

    d_sort_val[i] = i;  // 按原始位置索引排序
    // key 升序: 先按 block_id, block_id 相同时按 (1-score) 也就是 score 降序
    d_sort_key[i] = block_id * 1000000.0f + (1.0f - d_ext_scores[i]);
}

// 排序后重排: 把 extract 输出按 sorted order 写入 blk_idx/blk_sc/blk_cls
__global__ void spatialReorderAfterSortKernel(
    int num_boxes,
    const int* d_sorted_order,    // [num_boxes] sorted 后的原始 index 序列
    const int* d_ext_indices,     // [num_boxes] extract 输出的 index (=0..n-1)
    const float* d_ext_scores,    // [num_boxes] extract 输出的 score
    const int* d_ext_classes,     // [num_boxes] extract 输出的 class
    int* d_blk_idx,
    float* d_blk_sc,
    int* d_blk_cls
) {
    int i = threadIdx.x + blockIdx.x * blockDim.x;
    if (i >= num_boxes) return;
    int src = d_sorted_order[i];
    d_blk_idx[i] = d_ext_indices[src];
    d_blk_sc[i]  = d_ext_scores[src];
    d_blk_cls[i] = d_ext_classes[src];
}

// 从排序后的 key 中提取 block_id
__global__ void spatialExtractBlockIdKernel(
    int num_boxes,
    const float* d_sorted_key,
    int* d_sorted_bid
) {
    int i = threadIdx.x + blockIdx.x * blockDim.x;
    if (i >= num_boxes) return;
    d_sorted_bid[i] = (int)(d_sorted_key[i] / 1000000.0f);
}

// 从排序后的 block_id 数组构建每个 spatial block 的起始偏移
__global__ void spatialBuildBlockStartKernel(
    int num_boxes,
    int num_blocks,
    const int* d_sorted_bid,
    int* d_blk_start
) {
    int tid = threadIdx.x;

    // 初始化全为 0
    for (int i = tid; i <= num_blocks; i += blockDim.x) {
        d_blk_start[i] = 0;
    }
    __syncthreads();

    // 标记每个 block 首次出现的位置
    for (int i = tid; i < num_boxes - 1; i += blockDim.x) {
        int cur = d_sorted_bid[i];
        int next = d_sorted_bid[i + 1];
        if (cur != next) {
            d_blk_start[next] = i + 1;
        }
    }
    __syncthreads();

    // 最后一个块的结束
    if (tid == 0) {
        d_blk_start[num_blocks] = num_boxes;
    }
    __syncthreads();

    // 向前推进填充空块 (空块的 start 等于前一个块的 start)
    for (int i = 1; i <= num_blocks; i++) {
        if (d_blk_start[i] == 0 && i < num_blocks) {
            d_blk_start[i] = d_blk_start[i - 1];
        }
        __syncthreads();
    }
}

// ============================================================================
// Full Pipeline Functions (extract + sort/block + NMS, all on GPU, included in timing)
// ============================================================================

extern "C" void nonBlockNmsFull(
    cudaStream_t stream,
    const int batch_size,
    const int num_boxes,
    const float score_threshold,
    const float iou_threshold,
    const int max_output_boxes,
    const float* d_input,
    int* d_output_count,
    float* d_output_boxes,
    int* d_output_classes,
    float* d_output_scores,
    int* d_sorted_indices,
    float* d_sorted_scores,
    int* d_sorted_classes,
    int* d_temp_indices,
    float* d_temp_scores,
    int* d_temp_classes,
    void* d_temp_storage,
    size_t temp_storage_bytes,
    int* d_order
) {
    int threads = 256;

    for (int b = 0; b < batch_size; b++) {
        // Step 1: GPU extract
        int blocks = (num_boxes + threads - 1) / threads;
        extractScoresKernel<<<dim3(1, blocks), threads, 0, stream>>>(
            1, num_boxes, d_input + b * 84 * num_boxes,
            d_temp_indices, d_temp_scores, d_temp_classes);

        // Step 2: cub global sort descending by score
        cub::DeviceRadixSort::SortPairsDescending(
            d_temp_storage, temp_storage_bytes,
            d_temp_scores, d_sorted_scores + b * num_boxes,
            d_temp_indices, d_order, num_boxes, 0, sizeof(int) * 8, stream);

        // Step 3: reorder classes
        globalSortReorderKernel<<<(num_boxes + threads - 1) / threads, threads, 0, stream>>>(
            num_boxes, d_order, d_temp_indices, d_temp_scores, d_temp_classes,
            d_sorted_indices + b * num_boxes,
            d_sorted_scores + b * num_boxes,
            d_sorted_classes + b * num_boxes);

        // Step 4: nonBlockNmsKernel
        nonBlockNmsKernel<<<dim3(1, blocks), threads, 0, stream>>>(
            1, num_boxes, score_threshold, iou_threshold, max_output_boxes,
            d_input + b * 84 * num_boxes,
            d_output_count + b,
            d_output_boxes + b * max_output_boxes * 4,
            d_output_classes + b * max_output_boxes,
            d_output_scores + b * max_output_boxes,
            d_sorted_indices + b * num_boxes,
            d_sorted_scores + b * num_boxes,
            d_sorted_classes + b * num_boxes);
    }
}

extern "C" void blockNmsFull(
    cudaStream_t stream,
    const int batch_size,
    const int num_boxes,
    const float score_threshold,
    const float iou_threshold,
    const int max_output_boxes,
    const int block_size,
    const int overlap_extension,
    const float* d_input,
    int* d_output_count,
    float* d_output_boxes,
    int* d_output_classes,
    float* d_output_scores,
    int* d_sorted_indices,
    float* d_sorted_scores,
    int* d_sorted_classes,
    int* d_temp_indices,
    float* d_temp_scores,
    int* d_temp_classes
) {
    int threads = 256;

    for (int b = 0; b < batch_size; b++) {
        // Step 1: GPU extract
        int blocks = (num_boxes + threads - 1) / threads;
        extractScoresKernel<<<dim3(1, blocks), threads, 0, stream>>>(
            1, num_boxes, d_input + b * 84 * num_boxes,
            d_temp_indices, d_temp_scores, d_temp_classes);

        // Step 2: GPU block-local sort
        int num_full_blocks = num_boxes / block_size;
        int last_block_count = num_boxes % block_size;
        int total_cuda_blocks = num_full_blocks + (last_block_count > 0 ? 1 : 0);

        blockLocalSortKernel<<<total_cuda_blocks, threads, 0, stream>>>(
            num_boxes, block_size,
            d_temp_indices, d_temp_scores, d_temp_classes,
            d_sorted_indices + b * num_boxes,
            d_sorted_scores + b * num_boxes,
            d_sorted_classes + b * num_boxes);

        // Step 3: blockNmsKernel
        blockNmsKernel<<<dim3(1, blocks), threads, 0, stream>>>(
            1, num_boxes, score_threshold, iou_threshold, max_output_boxes,
            block_size, overlap_extension,
            d_input + b * 84 * num_boxes,
            d_output_count + b,
            d_output_boxes + b * max_output_boxes * 4,
            d_output_classes + b * max_output_boxes,
            d_output_scores + b * max_output_boxes,
            d_sorted_indices + b * num_boxes,
            d_sorted_scores + b * num_boxes,
            d_sorted_classes + b * num_boxes);
    }
}

extern "C" size_t spatialBlockNmsFullGetTempSize(int num_boxes) {
    size_t temp_bytes = 0;
    float *d_keys = nullptr, *d_keys_out = nullptr;
    int *d_vals = nullptr, *d_vals_out = nullptr;
    cub::DeviceRadixSort::SortPairs(nullptr, temp_bytes, d_keys, d_keys_out, d_vals, d_vals_out, num_boxes);
    return temp_bytes;
}

extern "C" void spatialBlockNmsFull(
    cudaStream_t stream,
    const int batch_size,
    const int num_boxes,
    const float image_size,
    const float overlap_pixels,
    const float score_threshold,
    const float iou_threshold,
    const int max_output_boxes,
    const int grid_x,
    const int grid_y,
    const float* d_input,
    int* d_output_count,
    float* d_output_boxes,
    int* d_output_classes,
    float* d_output_scores,
    int* d_blk_idx,
    float* d_blk_sc,
    int* d_blk_cls,
    int* d_blk_start,
    int* d_temp_indices,
    float* d_temp_scores,
    int* d_temp_classes,
    void* d_temp_storage,
    size_t temp_storage_bytes
) {
    int threads = 256;
    int num_blocks = grid_x * grid_y;

    for (int b = 0; b < batch_size; b++) {
        const float* d_in = d_input + b * 84 * num_boxes;

        // Step 1: GPU extract scores
        int extract_blocks = (num_boxes + threads - 1) / threads;
        extractScoresKernel<<<dim3(1, extract_blocks), threads, 0, stream>>>(
            1, num_boxes, d_in,
            d_temp_indices, d_temp_scores, d_temp_classes);

        // Step 2: assign sort_key = block_id * 1e6 + (1 - score)
        // d_blk_sc = key, d_blk_idx = value (original index)
        spatialAssignSortKeyKernel<<<(num_boxes + threads - 1) / threads, threads, 0, stream>>>(
            num_boxes, grid_x, grid_y, d_in, d_temp_scores,
            d_blk_idx, d_blk_sc);

        // Step 3: cub sort pairs ascending key
        // d_blk_sc (key) → d_temp_scores, d_blk_idx (value) → d_temp_indices
        cub::DeviceRadixSort::SortPairs(
            d_temp_storage, temp_storage_bytes,
            d_blk_sc, d_temp_scores,
            d_blk_idx, d_temp_indices,
            num_boxes, 0, sizeof(float)*8, stream);
        cudaStreamSynchronize(stream);

        // Step 4: extract block_id from sorted keys → d_temp_classes
        spatialExtractBlockIdKernel<<<(num_boxes + threads - 1) / threads, threads, 0, stream>>>(
            num_boxes, d_temp_scores, d_temp_classes);

        // Step 5: build block_start[0..num_blocks] → d_blk_start for this batch
        spatialBuildBlockStartKernel<<<1, 256, 0, stream>>>(
            num_boxes, num_blocks, d_temp_classes,
            d_blk_start + b * (num_blocks + 1));

        // Step 6: save sorted order (d_temp_indices) before re-extract overwrites it
        // d_blk_sc is no longer needed (sort keys consumed), reuse as sorted_order buffer
        cudaMemcpyAsync(d_blk_sc + b * num_boxes, d_temp_indices,
                        num_boxes * sizeof(int), cudaMemcpyDeviceToDevice, stream);

        // Step 7: re-extract scores/classes (d_temp_indices/d_temp_scores/d_temp_classes are dirty)
        extractScoresKernel<<<dim3(1, extract_blocks), threads, 0, stream>>>(
            1, num_boxes, d_in,
            d_temp_indices, d_temp_scores, d_temp_classes);

        // Step 8: reorder extract output by saved sorted order → d_blk_idx/blk_sc/blk_cls
        spatialReorderAfterSortKernel<<<(num_boxes + threads - 1) / threads, threads, 0, stream>>>(
            num_boxes,
            reinterpret_cast<const int*>(d_blk_sc + b * num_boxes), // saved sorted order (original index positions)
            d_temp_indices,             // fresh extract index
            d_temp_scores,              // fresh extract score
            d_temp_classes,             // fresh extract class
            d_blk_idx + b * num_boxes,
            d_blk_sc + b * num_boxes,   // overwrite saved order with final blk_sc
            d_blk_cls + b * num_boxes);

        // Step 9: run spatial block NMS kernel
        spatialBlockNmsKernel<<<dim3(1, num_blocks), threads, 0, stream>>>(
            1, num_boxes, score_threshold, iou_threshold, max_output_boxes,
            grid_x, grid_y, num_blocks,
            d_blk_idx + b * num_boxes,
            d_blk_sc + b * num_boxes,
            d_blk_cls + b * num_boxes,
            d_blk_start + b * (num_blocks + 1),
            d_in,
            d_output_count + b,
            d_output_boxes + b * max_output_boxes * 4,
            d_output_classes + b * max_output_boxes,
            d_output_scores + b * max_output_boxes);
    }
}
