# Block-FastNMS TensorRT Plugin

A high-performance CUDA implementation of the Block-FastNMS algorithm for real-time object detection, integrated as a TensorRT plugin.

## Overview

This plugin implements the Block-FastNMS algorithm for YOLO object detection, transforming traditional sequential NMS into a parallel thread-level operation. Key features:

- **Parallel NMS Execution**: Each CUDA thread processes one bounding box independently
- **Block-Based Optimization**: Divides image into spatial blocks (80x80 default) to improve parallelism
- **Efficient Comparison**: Reduces complexity from O(N²) to O(K×M²) where K=blocks, M=boxes per block
- **Memory-Efficient**: Overlap extension (8 pixels default) handles boundary targets without cross-block communication
- **Lightweight Deduplication**: Final stage ensures unique detection results

## Input/Output Specification

### Input
- **Shape**: `[B, 84, 8400]` (Batch, Features, Predictions)
  - B: Batch size (typically 1)
  - 84: xywh (4) + 80 class logits
  - 8400: Number of predicted boxes

- **Data Format**: Float32
- **Score Format**: Raw logits (requires sigmoid processing)

### Output
- **boxes**: `[B, M, 4]` - Bounding box coordinates (x, y, w, h)
- **scores**: `[B, M]` - Confidence scores after sigmoid
- **indices**: `[B, M]` - Original box indices
- M: Maximum output boxes (default 1000)

### Parameters
- **score_threshold (σ)**: 0.25 - Confidence threshold for filtering
- **iou_threshold (τ)**: 0.7 - IoU threshold for suppression
- **max_output_boxes (M)**: 1000 - Maximum detections per batch
- **block_size**: 80 - Spatial block dimension (pixels)
- **overlap_extension**: 8 - Extension for boundary handling (pixels)

## Algorithm

```
1. Sort boxes by confidence scores (descending)
2. For each box in parallel:
   a. Skip if confidence < σ
   b. Check against all higher-score boxes
   c. If IoU > τ with any box of same class, mark as suppressed
   d. Add unsuppressed box to output (max M boxes)
3. Atomic operations ensure thread-safe output position assignment
4. Lightweight deduplication in final stage
```

## Project Structure

```
blockfastnms/
├── CMakeLists.txt              # Build configuration
├── build.sh                    # Build script
├── README.md                   # This file
├── include/
│   └── block_fastnms_plugin.h  # Plugin header
├── src/
│   ├── block_fastnms_kernel.cu # CUDA kernel implementation
│   └── block_fastnms_plugin.cpp # TensorRT plugin wrapper
└── examples/
    └── test_inference.cpp      # Inference test code
```

## Building

### Prerequisites
- CUDA Toolkit (11.0+)
- TensorRT (8.0+)
- CMake (3.18+)
- GCC/Clang compiler

### Build Steps

```bash
# Navigate to project directory
cd blockfastnms

# Make build script executable
chmod +x build.sh

# Run build script
./build.sh

# Or manually:
mkdir -p build
cd build
cmake -DCMAKE_BUILD_TYPE=Release ..
make -j$(nproc)
cd ..
```

### Output Files
- `build/libblocknms_plugin.so` - Plugin shared library
- `build/test_inference` - Test executable

## Usage

### TensorRT Integration

```cpp
#include "block_fastnms_plugin.h"
#include <NvInfer.h>

// Create runtime and logger
nvinfer1::IRuntime* runtime = nvinfer1::createInferRuntime(logger);

// Load plugin
nvinfer1::IPluginCreator* creator = getPluginCreator();
nvinfer1::IPluginV2DynamicExt* plugin = creator->createPlugin(
    "BlockFastNMS", &fieldCollection);

// Use in network building...
```

### Direct Kernel Usage

```cpp
#include "block_fastnms_plugin.h"
#include <cuda_runtime.h>

// Allocate GPU memory
float* d_input_data;      // [B, 84, 8400]
int* d_output_indices;    // [B, M]
float* d_output_boxes;    // [B, M, 4]
float* d_output_scores;   // [B, M]
int* d_output_count;      // [B]

// Run kernel
blockFastNmsKernel(
    stream,
    batch_size,
    num_boxes,
    num_classes,
    score_threshold,   // 0.25f
    iou_threshold,     // 0.7f
    max_output_boxes,  // 1000
    block_size,        // 80
    overlap_extension, // 8
    d_input_data,
    d_output_count,
    d_output_indices,
    d_output_boxes,
    d_output_classes,
    d_output_scores
);
```

## Testing

```bash
# Run test executable
cd build
./test_inference

# Expected output:
# Block-FastNMS TensorRT Plugin Inference Test
# ============================================
# Input shape: [1, 84, 8400]
# Output shape: [1, 1000, 6]
# ...
```

## Performance Characteristics

### Complexity Analysis
- **Traditional NMS**: O(N²) where N = total boxes
- **Block-FastNMS**: O(K × M²) where K = number of blocks, M = boxes per block
- **Example**: For 8400 boxes in 640×640 image:
  - Traditional: ~70M comparisons
  - Block-based: ~16K comparisons (assuming 100 blocks, 92 boxes/block average)
  - **Speedup**: ~4000x (with parallelism)

### GPU Memory Usage
- Input: ~8.4 MB (8400 × 84 × 4 bytes)
- Output: ~16 MB (1000 × 4 floats + 1000 × 4 ints + 1000 floats)
- Working memory: ~50 MB (sorting, indices, etc.)
- **Total**: ~75 MB per batch

## Advanced Configuration

### Custom Block Size
For different image resolutions:
- 416×416: block_size = 52
- 608×608: block_size = 76
- 800×800: block_size = 100

### Tuning Thresholds
- **score_threshold**: Lower = more detections, higher precision recall trade-off
- **iou_threshold**: Lower = more aggressive suppression, fewer false positives
- **overlap_extension**: Larger = better boundary handling, more memory

## Known Limitations

1. Currently optimized for 8400 predictions (YOLO v5/v8 default)
2. Batch processing tested primarily with batch_size=1
3. Block optimization most effective on small object datasets
4. CPU sorting fallback (can be optimized with CUB library)

## Future Improvements

1. NVIDIA CUB-based GPU sorting for better performance
2. Adaptive block sizing based on object distribution
3. Multi-class optimization with shared suppression lists
4. Quantization support for INT8 inference

## License

This implementation is provided as-is for research and production use.

## References

- YOLO v5/v8 Object Detection
- TensorRT Plugin API
- CUDA Parallel Computing

## Author Notes

The Block-FastNMS algorithm significantly improves NMS performance by:
1. Parallelizing box comparisons (thread-level)
2. Spatial decomposition (block-level)
3. Atomic operations for thread-safe output
4. Minimal post-processing overhead

This makes it ideal for real-time inference on NVIDIA GPUs, particularly beneficial for edge devices and high-throughput scenarios.
