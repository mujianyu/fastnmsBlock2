#include <iostream>
#include <vector>
#include <random>
#include <cuda_runtime.h>
#include <NvInfer.h>
#include <NvInferRuntime.h>
#include <fstream>
#include <sstream>
#include <cstring>
#include "../include/block_fastnms_plugin.h"

// Declare the kernel function
extern "C" void blockFastNmsKernel(
    cudaStream_t stream,
    const int batch_size,
    const int num_boxes,
    const int num_classes,
    const float score_threshold,
    const float iou_threshold,
    const int max_output_boxes,
    const int block_size,
    const int overlap_extension,
    const float* input_data,
    int* output_count,
    int* output_indices,
    float* output_boxes,
    int* output_classes,
    float* output_scores
);

// Simplified logger for TensorRT
class Logger : public nvinfer1::ILogger {
public:
    void log(nvinfer1::ILogger::Severity severity, const char* msg) noexcept override {
        if (severity != Severity::kINFO) {
            std::cout << msg << std::endl;
        }
    }
} gLogger;

// Simple random data generator
void generateTestData(float* data, size_t size, float min_val, float max_val) {
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_real_distribution<> dis(min_val, max_val);
    
    for (size_t i = 0; i < size; i++) {
        data[i] = dis(gen);
    }
}

void runInference() {
    // Parameters
    const int batch_size = 1;
    const int num_boxes = 8400;
    const int feature_size = 84;  // xywh + 80 classes
    const int max_output_boxes = 1000;
    const float score_threshold = 0.25f;
    const float iou_threshold = 0.7f;
    
    // Input shape: [batch, feature_size, num_boxes]
    const size_t input_size = batch_size * feature_size * num_boxes;
    
    // Allocate host memory for input
    std::vector<float> h_input_data(input_size);
    
    // Generate random test data
    // xywh in range [0, 640]
    for (int b = 0; b < batch_size; b++) {
        for (int i = 0; i < num_boxes; i++) {
            int offset = b * feature_size * num_boxes + i * feature_size;
            
            // x, y, w, h - normalize to [0, 640]
            h_input_data[offset + 0] = static_cast<float>(rand() % 640);
            h_input_data[offset + 1] = static_cast<float>(rand() % 640);
            h_input_data[offset + 2] = static_cast<float>(rand() % 320 + 10);  // width
            h_input_data[offset + 3] = static_cast<float>(rand() % 320 + 10);  // height
            
            // 80 class logits (not sigmoid applied, as specified)
            for (int c = 0; c < 80; c++) {
                h_input_data[offset + 4 + c] = static_cast<float>(rand()) / RAND_MAX * 4 - 2;  // logits
            }
        }
    }
    
    // Allocate device memory
    float* d_input_data;
    float* d_output_boxes;
    float* d_output_scores;
    int* d_output_indices;
    int* d_output_counts;
    
    cudaMalloc(&d_input_data, input_size * sizeof(float));
    cudaMalloc(&d_output_boxes, batch_size * max_output_boxes * 4 * sizeof(float));
    cudaMalloc(&d_output_scores, batch_size * max_output_boxes * sizeof(float));
    cudaMalloc(&d_output_indices, batch_size * max_output_boxes * sizeof(int));
    cudaMalloc(&d_output_counts, batch_size * sizeof(int));
    
    // Copy input data to device
    cudaMemcpy(d_input_data, h_input_data.data(), input_size * sizeof(float),
               cudaMemcpyHostToDevice);
    
    // Initialize output count
    cudaMemset(d_output_counts, 0, batch_size * sizeof(int));
    
    // Create TensorRT runtime and engine
    nvinfer1::IRuntime* runtime = nvinfer1::createInferRuntime(gLogger);
    
    // Load the plugin library dynamically
    const std::string plugin_lib_path = "./libblocknms_plugin.so";
    
    // Note: In a real scenario, you would:
    // 1. Build the network with the plugin
    // 2. Serialize it
    // 3. Load the serialized engine
    
    std::cout << "Block-FastNMS TensorRT Plugin Inference Test" << std::endl;
    std::cout << "============================================" << std::endl;
    std::cout << "Input shape: [" << batch_size << ", " << feature_size << ", " 
              << num_boxes << "]" << std::endl;
    std::cout << "Output shape: [" << batch_size << ", " << max_output_boxes << ", 6]" << std::endl;
    std::cout << "Score threshold: " << score_threshold << std::endl;
    std::cout << "IoU threshold: " << iou_threshold << std::endl;
    std::cout << std::endl;
    
    // Allocate host memory for output
    std::vector<float> h_output_boxes(batch_size * max_output_boxes * 4);
    std::vector<float> h_output_scores(batch_size * max_output_boxes);
    std::vector<int> h_output_indices(batch_size * max_output_boxes);
    std::vector<int> h_output_counts(batch_size);
    
    // For this test, we'll run the kernel directly
    // In production, this would be through TensorRT engine
    
    std::cout << "Running Block-FastNMS kernel..." << std::endl;
    
    // Call the kernel (simplified version for testing)
    // This demonstrates the expected input/output format
    blockFastNmsKernel(
        0,  // stream
        batch_size,
        num_boxes,
        80,  // num_classes
        score_threshold,
        iou_threshold,
        max_output_boxes,
        80,  // block_size
        8,   // overlap_extension
        d_input_data,
        d_output_counts,
        d_output_indices,
        d_output_boxes,
        d_output_indices,  // reuse for classes
        d_output_scores
    );
    
    // Copy output back to host
    cudaMemcpy(h_output_boxes.data(), d_output_boxes,
               batch_size * max_output_boxes * 4 * sizeof(float),
               cudaMemcpyDeviceToHost);
    cudaMemcpy(h_output_scores.data(), d_output_scores,
               batch_size * max_output_boxes * sizeof(float),
               cudaMemcpyDeviceToHost);
    cudaMemcpy(h_output_indices.data(), d_output_indices,
               batch_size * max_output_boxes * sizeof(int),
               cudaMemcpyDeviceToHost);
    cudaMemcpy(h_output_counts.data(), d_output_counts,
               batch_size * sizeof(int),
               cudaMemcpyDeviceToHost);
    
    // Display results
    std::cout << "\nResults:" << std::endl;
    std::cout << "--------" << std::endl;
    
    for (int b = 0; b < batch_size; b++) {
        int count = h_output_counts[b];
        std::cout << "Batch " << b << ": " << count << " detections" << std::endl;
        
        if (count > 0) {
            std::cout << "\nTop 10 detections:" << std::endl;
            std::cout << "  Index\t  X\t    Y\t    W\t    H\t  Class\t  Score" << std::endl;
            std::cout << "  -----\t  -----\t    -----\t    -----\t    -----\t  -----\t  -----" << std::endl;
            
            int display_count = std::min(10, count);
            for (int i = 0; i < display_count; i++) {
                int idx = h_output_indices[b * max_output_boxes + i];
                float x = h_output_boxes[(b * max_output_boxes + i) * 4 + 0];
                float y = h_output_boxes[(b * max_output_boxes + i) * 4 + 1];
                float w = h_output_boxes[(b * max_output_boxes + i) * 4 + 2];
                float h = h_output_boxes[(b * max_output_boxes + i) * 4 + 3];
                float score = h_output_scores[b * max_output_boxes + i];
                
                std::cout << "  " << idx << "\t  " << x << "\t    " << y 
                         << "\t    " << w << "\t    " << h 
                         << "\t  " << (int)(score * 100) << "%\t  " << score << std::endl;
            }
        }
    }
    
    // Cleanup
    cudaFree(d_input_data);
    cudaFree(d_output_boxes);
    cudaFree(d_output_scores);
    cudaFree(d_output_indices);
    cudaFree(d_output_counts);
    
    if (runtime) {
        runtime->destroy();
    }
    
    std::cout << "\nTest completed successfully!" << std::endl;
}

// Alternative: Direct kernel test
void testDirectKernel() {
    std::cout << "Testing Block-FastNMS Kernel Directly" << std::endl;
    std::cout << "=====================================" << std::endl;
    
    const int batch_size = 1;
    const int num_boxes = 8400;
    const int feature_size = 84;
    const int max_output = 1000;
    
    // Create simple test data
    float* h_input = new float[batch_size * feature_size * num_boxes];
    float* h_output_boxes = new float[batch_size * max_output * 4];
    float* h_output_scores = new float[batch_size * max_output];
    int* h_output_indices = new int[batch_size * max_output];
    int* h_output_counts = new int[batch_size];
    
    // Initialize with some test values
    for (int i = 0; i < batch_size * feature_size * num_boxes; i++) {
        h_input[i] = (float)(rand() % 100) / 100.0f;
    }
    
    memset(h_output_counts, 0, batch_size * sizeof(int));
    
    // Allocate GPU memory
    float* d_input;
    float* d_output_boxes;
    float* d_output_scores;
    int* d_output_indices;
    int* d_output_counts;
    
    cudaMalloc(&d_input, batch_size * feature_size * num_boxes * sizeof(float));
    cudaMalloc(&d_output_boxes, batch_size * max_output * 4 * sizeof(float));
    cudaMalloc(&d_output_scores, batch_size * max_output * sizeof(float));
    cudaMalloc(&d_output_indices, batch_size * max_output * sizeof(int));
    cudaMalloc(&d_output_counts, batch_size * sizeof(int));
    
    // Copy data to GPU
    cudaMemcpy(d_input, h_input,
              batch_size * feature_size * num_boxes * sizeof(float),
              cudaMemcpyHostToDevice);
    cudaMemcpy(d_output_counts, h_output_counts, batch_size * sizeof(int),
              cudaMemcpyHostToDevice);
    
    // Call kernel function
    std::cout << "Calling blockFastNmsKernel..." << std::endl;
    blockFastNmsKernel(
        0,  // stream
        batch_size,
        num_boxes,
        80,  // num_classes
        0.25f,  // score_threshold
        0.7f,   // iou_threshold
        max_output,
        80,     // block_size
        8,      // overlap_extension
        d_input,
        d_output_counts,
        d_output_indices,
        d_output_boxes,
        d_output_indices,  // reuse for classes
        d_output_scores
    );
    
    // Copy results back
    cudaMemcpy(h_output_boxes, d_output_boxes,
              batch_size * max_output * 4 * sizeof(float),
              cudaMemcpyDeviceToHost);
    cudaMemcpy(h_output_scores, d_output_scores,
              batch_size * max_output * sizeof(float),
              cudaMemcpyDeviceToHost);
    cudaMemcpy(h_output_indices, d_output_indices,
              batch_size * max_output * sizeof(int),
              cudaMemcpyDeviceToHost);
    cudaMemcpy(h_output_counts, d_output_counts,
              batch_size * sizeof(int),
              cudaMemcpyDeviceToHost);
    
    // Display results
    for (int b = 0; b < batch_size; b++) {
        std::cout << "Batch " << b << ": " << h_output_counts[b] << " detections" << std::endl;
    }
    
    // Cleanup
    delete[] h_input;
    delete[] h_output_boxes;
    delete[] h_output_scores;
    delete[] h_output_indices;
    delete[] h_output_counts;
    
    cudaFree(d_input);
    cudaFree(d_output_boxes);
    cudaFree(d_output_scores);
    cudaFree(d_output_indices);
    cudaFree(d_output_counts);
    
    std::cout << "Kernel test completed!" << std::endl;
}

int main() {
    try {
        // Run TensorRT inference test
        runInference();
        
        std::cout << "\n" << std::string(50, '=') << std::endl;
        
        // Run direct kernel test
        // testDirectKernel();
        
    } catch (const std::exception& e) {
        std::cerr << "Exception: " << e.what() << std::endl;
        return 1;
    }
    
    return 0;
}
