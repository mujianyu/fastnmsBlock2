#!/usr/bin/env python3
"""
Block-FastNMS TensorRT Plugin - Python Integration Example

This example shows how to integrate the Block-FastNMS plugin with TensorRT
in a Python application for YOLO object detection.
"""

import numpy as np
import ctypes
import tensorrt as trt
from typing import Tuple, List, Dict

# TensorRT logger
logger = trt.Logger(trt.Logger.WARNING)

class BlockFastNMSPlugin:
    """Wrapper for Block-FastNMS TensorRT Plugin"""
    
    def __init__(
        self,
        plugin_path: str = "./build/lib/libblock_fastnms_plugin.so",
        score_threshold: float = 0.25,
        iou_threshold: float = 0.7,
        max_output_boxes: int = 1000,
        block_size: int = 80,
        overlap_extension: int = 8
    ):
        """
        Initialize Block-FastNMS plugin wrapper.
        
        Args:
            plugin_path: Path to the compiled plugin library
            score_threshold: Confidence threshold for filtering (default: 0.25)
            iou_threshold: IoU threshold for suppression (default: 0.7)
            max_output_boxes: Maximum output detections (default: 1000)
            block_size: Spatial block size in pixels (default: 80)
            overlap_extension: Boundary extension pixels (default: 8)
        """
        self.plugin_path = plugin_path
        self.score_threshold = score_threshold
        self.iou_threshold = iou_threshold
        self.max_output_boxes = max_output_boxes
        self.block_size = block_size
        self.overlap_extension = overlap_extension
        
        # Load CUDA library
        try:
            self.lib = ctypes.CDLL(plugin_path)
        except OSError as e:
            print(f"Error loading plugin library: {e}")
            print(f"Make sure {plugin_path} exists and is built")
            raise
    
    def create_network_with_nms(
        self,
        network: trt.INetworkDefinition,
        input_tensor: trt.ITensor,
        batch_size: int = 1
    ) -> Tuple[trt.ITensor, trt.ITensor, trt.ITensor]:
        """
        Add Block-FastNMS plugin to TensorRT network.
        
        Args:
            network: TensorRT network definition
            input_tensor: Input tensor from YOLO model [B, 84, 8400]
            batch_size: Batch size (default: 1)
            
        Returns:
            Tuple of (boxes, scores, indices) tensors
        """
        # Create plugin factory
        plugin_registry = trt.get_plugin_registry()
        
        # Get plugin creator
        creator = plugin_registry.get_creator_by_name("BlockFastNMS")
        if creator is None:
            raise RuntimeError(
                "BlockFastNMS plugin not found in registry. "
                "Make sure the plugin library is loaded."
            )
        
        # Create plugin fields
        field_names = ["score_threshold", "iou_threshold", "max_output_boxes", 
                      "block_size", "overlap_extension"]
        field_values = [self.score_threshold, self.iou_threshold, 
                       self.max_output_boxes, self.block_size, 
                       self.overlap_extension]
        
        fields = []
        for name, value in zip(field_names, field_values):
            field = trt.PluginField(name, np.array([value], dtype=np.float32), 
                                   trt.PluginFieldType.FLOAT32)
            fields.append(field)
        
        # Create plugin
        field_collection = trt.PluginFieldCollection(fields)
        plugin = creator.create_plugin("BlockFastNMS", field_collection)
        
        if plugin is None:
            raise RuntimeError("Failed to create BlockFastNMS plugin")
        
        # Add plugin layer
        plugin_layer = network.add_plugin_v2([input_tensor], [plugin])
        
        if plugin_layer is None:
            raise RuntimeError("Failed to add plugin layer to network")
        
        # Set output names
        plugin_layer.get_output(0).name = "boxes"
        plugin_layer.get_output(1).name = "scores"
        plugin_layer.get_output(2).name = "indices"
        
        return (plugin_layer.get_output(0), 
                plugin_layer.get_output(1), 
                plugin_layer.get_output(2))


class YOLODetector:
    """YOLO detector with Block-FastNMS plugin"""
    
    def __init__(
        self,
        model_path: str,
        plugin_path: str,
        input_size: int = 640
    ):
        """
        Initialize YOLO detector.
        
        Args:
            model_path: Path to YOLO ONNX or TensorRT engine
            plugin_path: Path to Block-FastNMS plugin
            input_size: Input image size (default: 640)
        """
        self.input_size = input_size
        self.nms = BlockFastNMSPlugin(plugin_path)
        self.engine = None
        self.context = None
        self.bindings = {}
        
        self._setup_engine(model_path)
    
    def _setup_engine(self, model_path: str):
        """Setup TensorRT engine with Block-FastNMS plugin"""
        # Load or build engine
        if model_path.endswith('.engine'):
            self._load_engine(model_path)
        elif model_path.endswith('.onnx'):
            self._build_engine_from_onnx(model_path)
        else:
            raise ValueError("Unsupported model format. Use .engine or .onnx")
    
    def _load_engine(self, engine_path: str):
        """Load pre-built TensorRT engine"""
        with open(engine_path, 'rb') as f:
            engine_data = f.read()
        
        runtime = trt.Runtime(logger)
        self.engine = runtime.deserialize_cuda_engine(engine_data)
        self.context = self.engine.create_execution_context()
    
    def _build_engine_from_onnx(self, onnx_path: str):
        """Build TensorRT engine from ONNX with Block-FastNMS plugin"""
        # This requires additional setup - implementation depends on
        # specific ONNX model structure
        raise NotImplementedError(
            "ONNX to TensorRT conversion requires custom implementation"
        )
    
    def detect(
        self,
        image: np.ndarray,
        conf_threshold: float = 0.25
    ) -> List[Dict]:
        """
        Run detection on image.
        
        Args:
            image: Input image (H, W, 3) in BGR format
            conf_threshold: Confidence threshold
            
        Returns:
            List of detections with format:
            [{'box': [x,y,w,h], 'class': int, 'score': float}, ...]
        """
        # Preprocess
        processed = self._preprocess(image)
        
        # Inference
        outputs = self._infer(processed)
        
        # Postprocess
        detections = self._postprocess(outputs)
        
        return detections
    
    def _preprocess(self, image: np.ndarray) -> np.ndarray:
        """Preprocess image for YOLO"""
        # Resize to input size
        # Normalize
        # Return as batch
        pass
    
    def _infer(self, input_data: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """Run inference"""
        # Set input bindings
        # Execute context
        # Get output bindings
        pass
    
    def _postprocess(
        self,
        outputs: Tuple[np.ndarray, np.ndarray, np.ndarray]
    ) -> List[Dict]:
        """Postprocess network outputs"""
        boxes, scores, indices = outputs
        
        detections = []
        for i in range(boxes.shape[1]):
            if scores[0, i] > 0:
                x, y, w, h = boxes[0, i]
                detection = {
                    'box': [float(x), float(y), float(w), float(h)],
                    'class': int(indices[0, i]),
                    'score': float(scores[0, i])
                }
                detections.append(detection)
        
        return detections


if __name__ == "__main__":
    print("Block-FastNMS TensorRT Plugin - Python Example")
    print("=" * 50)
    print()
    
    print("Usage:")
    print("------")
    print()
    print("1. Load plugin in TensorRT:")
    print("   import tensorrt as trt")
    print("   trt.init_libnvinfer_plugins(logger, namespace='')")
    print("   ")
    print("2. Create detector:")
    print("   detector = YOLODetector('model.engine', 'build/lib/libblock_fastnms_plugin.so')")
    print("   ")
    print("3. Run detection:")
    print("   detections = detector.detect(image)")
    print("   for det in detections:")
    print("       print(f'Class: {det[\"class\"]}, Score: {det[\"score\"]:.2f}')")
    print()
    print("Note: This is a template example. Full implementation requires")
    print("      specific YOLO model integration.")
