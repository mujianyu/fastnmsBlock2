#include <iostream>
#include <vector>
#include <random>
#include <cuda_runtime.h>
#include <iomanip>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <map>
#include <chrono>

// ============================================================================
// 外部函数声明 (kernel-only，不包括排序)
// ============================================================================

extern "C" void extractScores(
    cudaStream_t stream,
    int batch_size, int num_boxes,
    const float* d_input,
    int* d_indices, float* d_scores, int* d_classes);

extern "C" void nonBlockNmsKernelOnly(
    cudaStream_t stream,
    int batch_size, int num_boxes,
    float score_threshold, float iou_threshold,
    int max_output_boxes,
    const float* d_input,
    int* d_output_count, float* d_output_boxes,
    int* d_output_classes, float* d_output_scores,
    const int* d_sorted_indices, const float* d_sorted_scores, const int* d_sorted_classes);

extern "C" void blockNmsKernelOnly(
    cudaStream_t stream,
    int batch_size, int num_boxes,
    float score_threshold, float iou_threshold,
    int max_output_boxes,
    int block_size, int overlap_extension,
    const float* d_input,
    int* d_output_count, float* d_output_boxes,
    int* d_output_classes, float* d_output_scores,
    const int* d_sorted_indices, const float* d_sorted_scores, const int* d_sorted_classes);

extern "C" void spatialBlockNmsKernelOnly(
    cudaStream_t stream,
    int batch_size, int num_boxes,
    float image_size,
    float overlap_pixels,
    float score_threshold, float iou_threshold,
    int max_output_boxes,
    int grid_x, int grid_y,
    const float* d_input,
    int* d_output_count, float* d_output_boxes,
    int* d_output_classes, float* d_output_scores,
    const int* d_blk_idx, const float* d_blk_sc,
    const int* d_blk_cls, const int* d_blk_start);

// Full GPU pipeline: extract + spatial sort/block + NMS (all on GPU)
extern "C" size_t spatialBlockNmsFullGetTempSize(int num_boxes);

extern "C" void spatialBlockNmsFull(
    cudaStream_t stream,
    int batch_size, int num_boxes,
    float image_size,
    float overlap_pixels,
    float score_threshold, float iou_threshold,
    int max_output_boxes,
    int grid_x, int grid_y,
    const float* d_input,
    int* d_output_count, float* d_output_boxes,
    int* d_output_classes, float* d_output_scores,
    int* d_blk_idx, float* d_blk_sc,
    int* d_blk_cls, int* d_blk_start,
    int* d_temp_indices, float* d_temp_scores,
    int* d_temp_classes,
    void* d_temp_storage, size_t temp_storage_bytes);

// ============================================================================
// 数据结构
// ============================================================================

struct Detection {
    int class_id;
    float score;
    float x, y, w, h;
};

bool compareDetection(const Detection& a, const Detection& b) {
    if (a.class_id != b.class_id) return a.class_id < b.class_id;
    if (std::abs(a.score - b.score) > 0.001f) return a.score > b.score;
    if (std::abs(a.x - b.x) > 0.001f) return a.x < b.x;
    if (std::abs(a.y - b.y) > 0.001f) return a.y < b.y;
    return false;
}

struct RunResult {
    float time_ms;
    int detections;
    std::vector<Detection> dets;
};

// ============================================================================
// 工具函数
// ============================================================================

// 读取 GPU 检测输出并排序
std::vector<Detection> readDetections(int count, int max_output_boxes,
    float* d_scores, float* d_boxes, int* d_classes)
{
    std::vector<Detection> out;
    if (count <= 0) return out;
    int n = std::min(count, max_output_boxes);

    std::vector<float> hs(n), hb(n * 4);
    std::vector<int>   hc(n);
    cudaMemcpy(hs.data(), d_scores, n * sizeof(float), cudaMemcpyDeviceToHost);
    cudaMemcpy(hb.data(), d_boxes, n * 4 * sizeof(float), cudaMemcpyDeviceToHost);
    cudaMemcpy(hc.data(), d_classes, n * sizeof(int), cudaMemcpyDeviceToHost);

    for (int i = 0; i < n; i++) {
        Detection d;
        d.class_id = hc[i];
        d.score    = hs[i];
        d.x = hb[i * 4 + 0]; d.y = hb[i * 4 + 1];
        d.w = hb[i * 4 + 2]; d.h = hb[i * 4 + 3];
        out.push_back(d);
    }
    std::sort(out.begin(), out.end(), compareDetection);
    return out;
}

// 比较两个排序后的检测结果
int countMismatches(const std::vector<Detection>& a, const std::vector<Detection>& b) {
    if (a.size() != b.size())
        return std::abs((int)(a.size() - b.size())) + 1000;

    int m = 0;
    for (size_t i = 0; i < a.size(); i++) {
        if (a[i].class_id != b[i].class_id) m++;
        if (std::abs(a[i].score - b[i].score) > 0.001f) m++;
        if (std::abs(a[i].x - b[i].x) > 0.001f) m++;
        if (std::abs(a[i].y - b[i].y) > 0.001f) m++;
    }
    return m;
}

float computeIoUCPU(float x1, float y1, float w1, float h1,
    float x2, float y2, float w2, float h2)
{
    float left1 = x1 - w1 * 0.5f;
    float right1 = x1 + w1 * 0.5f;
    float top1 = y1 - h1 * 0.5f;
    float bottom1 = y1 + h1 * 0.5f;

    float left2 = x2 - w2 * 0.5f;
    float right2 = x2 + w2 * 0.5f;
    float top2 = y2 - h2 * 0.5f;
    float bottom2 = y2 + h2 * 0.5f;

    float inter_left = std::max(left1, left2);
    float inter_right = std::min(right1, right2);
    float inter_top = std::max(top1, top2);
    float inter_bottom = std::min(bottom1, bottom2);

    float inter_w = std::max(0.0f, inter_right - inter_left);
    float inter_h = std::max(0.0f, inter_bottom - inter_top);
    float inter_area = inter_w * inter_h;

    float area1 = w1 * h1;
    float area2 = w2 * h2;
    float union_area = area1 + area2 - inter_area;
    if (union_area <= 0.0f) return 0.0f;
    return inter_area / union_area;
}

void buildSpatialBlockSorted(
    int num_boxes,
    int grid_x, int grid_y,
    float image_size,
    float overlap_pixels,
    const float* h_input,
    const int* h_indices,
    const float* h_sc,
    const int* h_cls,
    int* blk_idx,
    float* blk_sc,
    int* blk_cls,
    int* blk_start,
    int* blk_count)
{
    int num_blocks = grid_x * grid_y;
    float block_w = 1.0f / grid_x;
    float block_h = 1.0f / grid_y;
    (void)image_size;
    (void)overlap_pixels;

    std::vector<std::vector<int>> blocks(num_blocks);
    for (int i = 0; i < num_boxes; i++) {
        float cx = h_input[i * 84 + 0];
        float cy = h_input[i * 84 + 1];
        int bx = std::min(grid_x - 1, std::max(0, (int)(cx / block_w)));
        int by = std::min(grid_y - 1, std::max(0, (int)(cy / block_h)));
        blocks[by * grid_x + bx].push_back(i);
    }

    int out_pos = 0;
    blk_start[0] = 0;
    for (int block = 0; block < num_blocks; block++) {
        auto& ids = blocks[block];
        std::sort(ids.begin(), ids.end(), [&](int a, int b) {
            return h_sc[a] > h_sc[b];
        });

        int count = (int)ids.size();
        blk_count[block] = count;
        for (int i = 0; i < count; i++) {
            int idx = ids[i];
            blk_idx[out_pos] = h_indices[idx];
            blk_sc[out_pos] = h_sc[idx];
            blk_cls[out_pos] = h_cls[idx];
            out_pos++;
        }
        blk_start[block + 1] = out_pos;
    }
}

std::vector<Detection> spatialBlockFastNms(
    int num_boxes,
    int grid_x, int grid_y,
    float image_size,
    float overlap_pixels,
    const float* h_input,
    const int* blk_idx,
    const float* blk_sc,
    const int* blk_cls,
    const int* blk_start,
    const int* blk_count,
    const int* h_cls,
    float score_threshold,
    float iou_threshold)
{
    int num_blocks = grid_x * grid_y;
    (void)image_size;
    (void)overlap_pixels;
    std::vector<std::vector<int>> selected(num_blocks);
    std::vector<std::vector<int>> neighbors(num_blocks);
    for (int by = 0; by < grid_y; by++) {
        for (int bx = 0; bx < grid_x; bx++) {
            int block = by * grid_x + bx;
            for (int dy = -1; dy <= 1; dy++) {
                for (int dx = -1; dx <= 1; dx++) {
                    int nbx = bx + dx;
                    int nby = by + dy;
                    if (nbx < 0 || nbx >= grid_x || nby < 0 || nby >= grid_y) continue;
                    neighbors[block].push_back(nby * grid_x + nbx);
                }
            }
        }
    }

    std::vector<Detection> out;
    out.reserve(num_boxes);

    for (int block = 0; block < num_blocks; block++) {
        int start = blk_start[block];
        int end = blk_start[block + 1];

        for (int pos = start; pos < end; pos++) {
            float score = blk_sc[pos];
            if (score < score_threshold) continue;

            int box_idx = blk_idx[pos];
            int cls = blk_cls[pos];
            float x = h_input[box_idx * 84 + 0];
            float y = h_input[box_idx * 84 + 1];
            float w = h_input[box_idx * 84 + 2];
            float h = h_input[box_idx * 84 + 3];

            bool suppressed = false;
            for (int nb : neighbors[block]) {
                for (int sel_idx : selected[nb]) {
                    if (h_cls[sel_idx] != cls) continue;
                    float x2 = h_input[sel_idx * 84 + 0];
                    float y2 = h_input[sel_idx * 84 + 1];
                    float w2 = h_input[sel_idx * 84 + 2];
                    float h2 = h_input[sel_idx * 84 + 3];
                    float iou = computeIoUCPU(x, y, w, h, x2, y2, w2, h2);
                    if (iou > iou_threshold) {
                        suppressed = true;
                        break;
                    }
                }
                if (suppressed) break;
            }

            if (!suppressed) {
                selected[block].push_back(box_idx);
                Detection det;
                det.class_id = cls;
                det.score = score;
                det.x = x;
                det.y = y;
                det.w = w;
                det.h = h;
                out.push_back(det);
            }
        }
    }

    std::sort(out.begin(), out.end(), compareDetection);
    return out;
}

// 计时 kernel (不分块)
float timeNonBlockMs(cudaStream_t stream,
    int batch_size, int num_boxes,
    float score_thr, float iou_thr, int max_out,
    const float* d_input,
    int* d_counts, float* d_boxes, int* d_classes, float* d_scores,
    const int* d_sorted_idx, const float* d_sorted_sc, const int* d_sorted_cls)
{
    cudaEvent_t start, end;
    cudaEventCreate(&start);
    cudaEventCreate(&end);

    cudaMemsetAsync(d_counts, 0, batch_size * sizeof(int), stream);
    cudaStreamSynchronize(stream);

    cudaEventRecord(start, stream);
    nonBlockNmsKernelOnly(stream, batch_size, num_boxes, score_thr, iou_thr, max_out,
           d_input, d_counts, d_boxes, d_classes, d_scores,
           d_sorted_idx, d_sorted_sc, d_sorted_cls);
    cudaEventRecord(end, stream);
    cudaEventSynchronize(end);

    float ms = 0;
    cudaEventElapsedTime(&ms, start, end);
    cudaEventDestroy(start);
    cudaEventDestroy(end);
    return ms;
}

// 计时 kernel (分块)
float timeBlockMs(cudaStream_t stream, int block_sz, int overlap_sz,
    int batch_size, int num_boxes,
    float score_thr, float iou_thr, int max_out,
    const float* d_input,
    int* d_counts, float* d_boxes, int* d_classes, float* d_scores,
    const int* d_sorted_idx, const float* d_sorted_sc, const int* d_sorted_cls)
{
    cudaEvent_t start, end;
    cudaEventCreate(&start);
    cudaEventCreate(&end);

    cudaMemsetAsync(d_counts, 0, batch_size * sizeof(int), stream);
    cudaStreamSynchronize(stream);

    cudaEventRecord(start, stream);
    blockNmsKernelOnly(stream, batch_size, num_boxes, score_thr, iou_thr, max_out,
           block_sz, overlap_sz,
           d_input, d_counts, d_boxes, d_classes, d_scores,
           d_sorted_idx, d_sorted_sc, d_sorted_cls);
    cudaEventRecord(end, stream);
    cudaEventSynchronize(end);

    float ms = 0;
    cudaEventElapsedTime(&ms, start, end);
    cudaEventDestroy(start);
    cudaEventDestroy(end);
    return ms;
}

float timeSpatialBlockMs(cudaStream_t stream,
    int batch_size, int num_boxes,
    float image_size,
    float overlap_pixels,
    float score_thr, float iou_thr,
    int max_out,
    int grid_x, int grid_y,
    const float* d_input,
    int* d_counts, float* d_boxes, int* d_classes, float* d_scores,
    const int* d_blk_idx, const float* d_blk_sc,
    const int* d_blk_cls, const int* d_blk_start)
{
    cudaEvent_t start, end;
    cudaEventCreate(&start);
    cudaEventCreate(&end);

    cudaMemsetAsync(d_counts, 0, batch_size * sizeof(int), stream);
    cudaStreamSynchronize(stream);

    cudaEventRecord(start, stream);
    spatialBlockNmsKernelOnly(stream, batch_size, num_boxes,
           image_size, overlap_pixels,
           score_thr, iou_thr, max_out,
           grid_x, grid_y,
           d_input, d_counts, d_boxes, d_classes, d_scores,
           d_blk_idx, d_blk_sc, d_blk_cls, d_blk_start);
    cudaEventRecord(end, stream);
    cudaEventSynchronize(end);

    float ms = 0;
    cudaEventElapsedTime(&ms, start, end);
    cudaEventDestroy(start);
    cudaEventDestroy(end);
    return ms;
}

// 计时 kernel: Spatial 8x8 Full GPU Pipeline (extract + sort + block + NMS all on GPU)
float timeSpatialBlockFullMs(cudaStream_t stream,
    int batch_size, int num_boxes,
    float image_size,
    float overlap_pixels,
    float score_thr, float iou_thr,
    int max_out,
    int grid_x, int grid_y,
    const float* d_input,
    int* d_counts, float* d_boxes, int* d_classes, float* d_scores,
    int* d_blk_idx, float* d_blk_sc,
    int* d_blk_cls, int* d_blk_start,
    int* d_temp_indices, float* d_temp_scores,
    int* d_temp_classes,
    void* d_temp_storage, size_t temp_bytes)
{
    cudaEvent_t start, end;
    cudaEventCreate(&start);
    cudaEventCreate(&end);

    cudaMemsetAsync(d_counts, 0, batch_size * sizeof(int), stream);
    cudaStreamSynchronize(stream);

    cudaEventRecord(start, stream);
    spatialBlockNmsFull(stream, batch_size, num_boxes,
           image_size, overlap_pixels,
           score_thr, iou_thr, max_out,
           grid_x, grid_y,
           d_input, d_counts, d_boxes, d_classes, d_scores,
           d_blk_idx, d_blk_sc, d_blk_cls, d_blk_start,
           d_temp_indices, d_temp_scores, d_temp_classes,
           d_temp_storage, temp_bytes);
    cudaEventRecord(end, stream);
    cudaEventSynchronize(end);

    float ms = 0;
    cudaEventElapsedTime(&ms, start, end);
    cudaEventDestroy(start);
    cudaEventDestroy(end);
    return ms;
}

// ============================================================================
// 构建块内排序的索引 (每块独立按分数降序)
// ============================================================================
void buildBlockSorted(
    int num_boxes, int block_size,
    const int* h_indices, const float* h_sc, const int* h_cls,
    int* blk_idx, float* blk_sc, int* blk_cls)
{
    int num_blocks = (num_boxes + block_size - 1) / block_size;
    for (int blk = 0; blk < num_blocks; blk++) {
        int start = blk * block_size;
        int end   = std::min(start + block_size, num_boxes);
        int count = end - start;

        std::vector<int> order(count);
        for (int i = 0; i < count; i++) order[i] = i;
        std::sort(order.begin(), order.end(), [&](int i, int j) {
            return h_sc[start + i] > h_sc[start + j];
        });

        for (int i = 0; i < count; i++) {
            int src = start + order[i];
            blk_idx[start + i] = h_indices[src];
            blk_sc[start + i]  = h_sc[src];
            blk_cls[start + i] = h_cls[src];
        }
    }
}

// ============================================================================
// 主 benchmark 函数
// ============================================================================

int main() {
    const int WARMUP = 2;
    const int ITERS  = 5;
    const int batch_size = 1;
    const int max_output_boxes = 11000;
    const float score_threshold = 0.1f;   // 所有框参与比较
    const float iou_threshold = 0.5f;

    std::vector<int> box_counts = {10,20,30,40,50,60,70,80,90,100, 200, 300, 400, 500, 600, 700, 800, 900, 1000};

    // 分块参数配置
    struct BlockConfig { int block_size; int overlap; const char* label; };
    std::vector<BlockConfig> configs = {
        {50,  25,  "block=50, overlap=25" },
        {100, 50,  "block=100, overlap=50"},
        {100, 100, "block=100, overlap=100"},
        {100, 200, "block=100, overlap=200"},
        {200, 100, "block=200, overlap=100"},
    };

    std::cout << "\n"
              << "================================================================================" << std::endl
              << "  NMS Benchmark: Block vs Non-Block Speed Comparison" << std::endl
              << "  Non-block: global sort + full O(N^2) scan" << std::endl
              << "  Block:     block-local sort + limited-range scan per block" << std::endl
              << "================================================================================" << std::endl
              << std::endl
              << "Params: batch=" << batch_size << ", score_thr=" << score_threshold
              << ", iou_thr=" << iou_threshold << ", max_output=" << max_output_boxes << std::endl
              << "Setup:  Non-block uses global sort; Block uses per-block local sort" << std::endl
              << "Timing: " << WARMUP << " warmup + " << ITERS << " timed runs (median)" << std::endl
              << "  Note: block NMS result equality depends on overlap parameter!" << std::endl
              << std::string(80, '-') << std::endl
              << std::endl;

    // =========================================================================
    // 主循环：每个 box count
    // =========================================================================

    // 非分块 baseline (每个 N 只跑一次，使用全局排序)
    std::vector<RunResult> baseline_results;

    for (int num_boxes : box_counts) {
        std::cout << "=== " << num_boxes << " boxes ===" << std::endl;

        // ---- 生成固定数据 (网格排列，不重叠) ----
        const size_t input_sz = batch_size * 84 * num_boxes;
        float* h_input = new float[input_sz];
        {
            int cols = (int)std::ceil(std::sqrt((float)num_boxes));
            float cell_w = 1.0f / cols;
            for (int idx = 0; idx < num_boxes; idx++) {
                int base = idx * 84;
                int row = idx / cols;
                int col = idx % cols;
                float cx = (col + 0.5f) * cell_w;
                float cy = (row + 0.5f) * cell_w;
                float hw = cell_w * 0.45f;
                h_input[base + 0] = cx;
                h_input[base + 1] = cy;
                h_input[base + 2] = hw * 2;
                h_input[base + 3] = hw * 2;
                h_input[base + 4 + 0] = 10.0f;
                for (int c = 1; c < 80; c++)
                    h_input[base + 4 + c] = -10.0f;
            }
        }

        // ---- GPU 内存分配 ----
        float *d_input, *d_boxes, *d_scores;
        int *d_classes, *d_counts;
        int *d_sorted_idx;
        float *d_sorted_sc;
        int *d_sorted_cls;

        cudaMalloc(&d_input,      input_sz * sizeof(float));
        cudaMalloc(&d_boxes,      batch_size * max_output_boxes * 4 * sizeof(float));
        cudaMalloc(&d_scores,     batch_size * max_output_boxes * sizeof(float));
        cudaMalloc(&d_classes,    batch_size * max_output_boxes * sizeof(int));
        cudaMalloc(&d_counts,     batch_size * sizeof(int));
        cudaMalloc(&d_sorted_idx, batch_size * num_boxes * sizeof(int));
        cudaMalloc(&d_sorted_sc,  batch_size * num_boxes * sizeof(float));
        cudaMalloc(&d_sorted_cls, batch_size * num_boxes * sizeof(int));

        cudaMemcpy(d_input, h_input, input_sz * sizeof(float), cudaMemcpyHostToDevice);

        cudaStream_t stream;
        cudaStreamCreate(&stream);

        // ---- Step 1: GPU 提取分数 ----
        extractScores(stream, batch_size, num_boxes, d_input,
                      d_sorted_idx, d_sorted_sc, d_sorted_cls);

        int* h_indices = new int[num_boxes];
        float* h_sc = new float[num_boxes];
        int* h_cls = new int[num_boxes];

        cudaMemcpy(h_indices, d_sorted_idx, num_boxes * sizeof(int), cudaMemcpyDeviceToHost);
        cudaMemcpy(h_sc, d_sorted_sc, num_boxes * sizeof(float), cudaMemcpyDeviceToHost);
        cudaMemcpy(h_cls, d_sorted_cls, num_boxes * sizeof(int), cudaMemcpyDeviceToHost);

        // ---- Step 2a: 全局排序 (给 non-block NMS 使用) ----
        int* global_idx = new int[num_boxes];
        float* global_sc = new float[num_boxes];
        int* global_cls = new int[num_boxes];

        {
            std::vector<int> order(num_boxes);
            for (int i = 0; i < num_boxes; i++) order[i] = i;
            std::sort(order.begin(), order.end(), [&](int i, int j) {
                return h_sc[i] > h_sc[j];
            });
            for (int i = 0; i < num_boxes; i++) {
                int src = order[i];
                global_idx[i] = h_indices[src];
                global_sc[i]  = h_sc[src];
                global_cls[i] = h_cls[src];
            }
        }

        // 上传全局排序到 GPU
        cudaMemcpy(d_sorted_idx, global_idx, num_boxes * sizeof(int), cudaMemcpyHostToDevice);
        cudaMemcpy(d_sorted_sc,  global_sc,  num_boxes * sizeof(float), cudaMemcpyHostToDevice);
        cudaMemcpy(d_sorted_cls, global_cls, num_boxes * sizeof(int), cudaMemcpyHostToDevice);

        // ---- Baseline: Non-block NMS (全局排序) ----
        std::cout << "  Baseline (non-block, global sort): " << std::flush;

        for (int i = 0; i < WARMUP; i++) {
            cudaMemsetAsync(d_counts, 0, batch_size * sizeof(int), stream);
            cudaStreamSynchronize(stream);
            nonBlockNmsKernelOnly(stream, batch_size, num_boxes,
                                  score_threshold, iou_threshold, max_output_boxes,
                                  d_input, d_counts, d_boxes, d_classes, d_scores,
                                  d_sorted_idx, d_sorted_sc, d_sorted_cls);
        }

        std::vector<float> times;
        for (int i = 0; i < ITERS; i++) {
            float t = timeNonBlockMs(stream,
                                   batch_size, num_boxes,
                                   score_threshold, iou_threshold, max_output_boxes,
                                   d_input, d_counts, d_boxes, d_classes, d_scores,
                                   d_sorted_idx, d_sorted_sc, d_sorted_cls);
            times.push_back(t);
        }
        std::sort(times.begin(), times.end());
        float median_t = times[ITERS / 2];

        int ref_count = 0;
        cudaMemcpy(&ref_count, d_counts, sizeof(int), cudaMemcpyDeviceToHost);
        auto ref_dets = readDetections(ref_count, max_output_boxes, d_scores, d_boxes, d_classes);

        RunResult ref;
        ref.time_ms = median_t;
        ref.detections = ref_count;
        ref.dets = ref_dets;
        baseline_results.push_back(ref);

        std::cout << std::fixed << std::setprecision(3) << median_t
                  << " ms, " << ref_count << " kept" << std::endl;

        // ---- Block NMS: 测试多个配置 (块内排序) ----
        std::cout << "  Block variants (block-local sort):" << std::endl;

        std::cout << "    " << std::left << std::setw(30) << "config"
                  << std::setw(12) << "time(ms)" << std::setw(10) << "speedup"
                  << std::setw(12) << "detections" << "result match" << std::endl;
        std::cout << "    " << std::string(80, '-') << std::endl;

        for (auto& cfg : configs) {
            if (cfg.block_size > num_boxes) continue;

            // Step 2b: 块内排序 (每块独立排序，不跨块)
            int* blk_idx = new int[num_boxes];
            float* blk_sc = new float[num_boxes];
            int* blk_cls = new int[num_boxes];
            buildBlockSorted(num_boxes, cfg.block_size, h_indices, h_sc, h_cls,
                           blk_idx, blk_sc, blk_cls);

            cudaMemcpy(d_sorted_idx, blk_idx, num_boxes * sizeof(int), cudaMemcpyHostToDevice);
            cudaMemcpy(d_sorted_sc,  blk_sc,  num_boxes * sizeof(float), cudaMemcpyHostToDevice);
            cudaMemcpy(d_sorted_cls, blk_cls, num_boxes * sizeof(int), cudaMemcpyHostToDevice);

            delete[] blk_idx;
            delete[] blk_sc;
            delete[] blk_cls;

            // warmup
            for (int i = 0; i < WARMUP; i++) {
                cudaMemsetAsync(d_counts, 0, batch_size * sizeof(int), stream);
                cudaStreamSynchronize(stream);
                blockNmsKernelOnly(stream, batch_size, num_boxes,
                                   score_threshold, iou_threshold, max_output_boxes,
                                   cfg.block_size, cfg.overlap,
                                   d_input, d_counts, d_boxes, d_classes, d_scores,
                                   d_sorted_idx, d_sorted_sc, d_sorted_cls);
            }

            // timed
            std::vector<float> bt;
            for (int i = 0; i < ITERS; i++) {
                float t = timeBlockMs(stream, cfg.block_size, cfg.overlap,
                    batch_size, num_boxes,
                    score_threshold, iou_threshold, max_output_boxes,
                    d_input, d_counts, d_boxes, d_classes, d_scores,
                    d_sorted_idx, d_sorted_sc, d_sorted_cls);
                bt.push_back(t);
            }
            std::sort(bt.begin(), bt.end());
            float bt_median = bt[ITERS / 2];

            int bcount = 0;
            cudaMemcpy(&bcount, d_counts, sizeof(int), cudaMemcpyDeviceToHost);
            auto bdets = readDetections(bcount, max_output_boxes, d_scores, d_boxes, d_classes);
            int mismatches = countMismatches(ref_dets, bdets);
            float speedup = (bt_median > 0.001f) ? median_t / bt_median : 0.0f;

            std::cout << "    " << std::left << std::setw(30) << cfg.label
                      << std::fixed << std::setprecision(3) << std::setw(12) << bt_median
                      << std::setprecision(2) << std::setw(10) << speedup << "x"
                      << std::setw(12) << bcount;

            if (mismatches == 0 && bcount == ref_count)
                std::cout << "IDENTICAL" << std::endl;
            else
                std::cout << mismatches << " diffs" << std::endl;
        }

        // ---- Spatial 8x8 坐标分块 + 4px overlap + GPU local fast NMS ----
        {
            const int GRID_X = 8;
            const int GRID_Y = 8;
            const int NUM_BLOCKS = GRID_X * GRID_Y;
            const float IMAGE_SIZE = 640.0f;
            const float OVERLAP_PX = 4.0f;

            // Step 2c: 坐标分块 + 块内按分数降序
            int* spatial_blk_idx = new int[num_boxes];
            float* spatial_blk_sc = new float[num_boxes];
            int* spatial_blk_cls = new int[num_boxes];
            int* spatial_blk_start = new int[NUM_BLOCKS + 1];
            int* spatial_blk_count = new int[NUM_BLOCKS];

            buildSpatialBlockSorted(
                num_boxes, GRID_X, GRID_Y, IMAGE_SIZE, OVERLAP_PX,
                h_input, h_indices, h_sc, h_cls,
                spatial_blk_idx, spatial_blk_sc, spatial_blk_cls,
                spatial_blk_start, spatial_blk_count);

            // 上传 spatial block 元数据到 GPU
            int* d_spatial_blk_idx;
            float* d_spatial_blk_sc;
            int* d_spatial_blk_cls;
            int* d_spatial_blk_start;
            cudaMalloc(&d_spatial_blk_idx,   batch_size * num_boxes * sizeof(int));
            cudaMalloc(&d_spatial_blk_sc,    batch_size * num_boxes * sizeof(float));
            cudaMalloc(&d_spatial_blk_cls,   batch_size * num_boxes * sizeof(int));
            cudaMalloc(&d_spatial_blk_start, batch_size * (NUM_BLOCKS + 1) * sizeof(int));
            cudaMemcpy(d_spatial_blk_idx,   spatial_blk_idx,   num_boxes * sizeof(int), cudaMemcpyHostToDevice);
            cudaMemcpy(d_spatial_blk_sc,    spatial_blk_sc,    num_boxes * sizeof(float), cudaMemcpyHostToDevice);
            cudaMemcpy(d_spatial_blk_cls,   spatial_blk_cls,   num_boxes * sizeof(int), cudaMemcpyHostToDevice);
            cudaMemcpy(d_spatial_blk_start, spatial_blk_start, (NUM_BLOCKS + 1) * sizeof(int), cudaMemcpyHostToDevice);

            // warmup
            for (int i = 0; i < WARMUP; i++) {
                cudaMemsetAsync(d_counts, 0, batch_size * sizeof(int), stream);
                cudaStreamSynchronize(stream);
                spatialBlockNmsKernelOnly(stream, batch_size, num_boxes,
                    IMAGE_SIZE, OVERLAP_PX,
                    score_threshold, iou_threshold, max_output_boxes,
                    GRID_X, GRID_Y,
                    d_input, d_counts, d_boxes, d_classes, d_scores,
                    d_spatial_blk_idx, d_spatial_blk_sc,
                    d_spatial_blk_cls, d_spatial_blk_start);
            }

            // timed
            std::vector<float> st;
            for (int i = 0; i < ITERS; i++) {
                float t = timeSpatialBlockMs(stream,
                    batch_size, num_boxes,
                    IMAGE_SIZE, OVERLAP_PX,
                    score_threshold, iou_threshold, max_output_boxes,
                    GRID_X, GRID_Y,
                    d_input, d_counts, d_boxes, d_classes, d_scores,
                    d_spatial_blk_idx, d_spatial_blk_sc,
                    d_spatial_blk_cls, d_spatial_blk_start);
                st.push_back(t);
            }
            std::sort(st.begin(), st.end());
            float spatial_ms = st[ITERS / 2];

            int scount = 0;
            cudaMemcpy(&scount, d_counts, sizeof(int), cudaMemcpyDeviceToHost);
            auto sdets = readDetections(scount, max_output_boxes, d_scores, d_boxes, d_classes);
            int mismatches = countMismatches(ref_dets, sdets);
            float speedup = (spatial_ms > 0.001f) ? median_t / spatial_ms : 0.0f;

            std::cout << "    " << std::left << std::setw(30) << "spatial 8x8 overlap=4px"
                      << std::fixed << std::setprecision(3) << std::setw(12) << spatial_ms
                      << std::setprecision(2) << std::setw(10) << speedup << "x"
                      << std::setw(12) << scount;
            if (mismatches == 0 && scount == ref_count)
                std::cout << "IDENTICAL" << std::endl;
            else
                std::cout << mismatches << " diffs" << std::endl;

            // ---- Spatial 8x8 GPU Full Pipeline (extract + sort + block + NMS all on GPU) ----
            {
                const int SF_GRID_X = 8;
                const int SF_GRID_Y = 8;
                const int SF_NUM_BLOCKS = SF_GRID_X * SF_GRID_Y;
                const float SF_IMAGE_SIZE = 640.0f;
                const float SF_OVERLAP_PX = 4.0f;

                // Allocate GPU buffers for Full pipeline
                int* d_sf_blk_idx;
                float* d_sf_blk_sc;
                int* d_sf_blk_cls;
                int* d_sf_blk_start;

                // temp buffers for extract (reused per-batch inside Full)
                int* d_sf_temp_idx;
                float* d_sf_temp_sc;
                int* d_sf_temp_cl;

                // Full GPU output buffers
                int* d_sf_full_cnt;
                float* d_sf_full_bx;
                float* d_sf_full_scores;
                int* d_sf_full_classes;

                // cub temp storage
                size_t cub_bytes = spatialBlockNmsFullGetTempSize(num_boxes);
                void* d_cub_storage = nullptr;
                cudaMalloc(&d_cub_storage, cub_bytes);

                cudaMalloc(&d_sf_blk_idx,   batch_size * num_boxes * sizeof(int));
                cudaMalloc(&d_sf_blk_sc,    batch_size * num_boxes * sizeof(float));
                cudaMalloc(&d_sf_blk_cls,   batch_size * num_boxes * sizeof(int));
                cudaMalloc(&d_sf_blk_start, batch_size * (SF_NUM_BLOCKS + 1) * sizeof(int));
                cudaMalloc(&d_sf_temp_idx,  num_boxes * sizeof(int));
                cudaMalloc(&d_sf_temp_sc,   num_boxes * sizeof(float));
                cudaMalloc(&d_sf_temp_cl,   num_boxes * sizeof(int));
                cudaMalloc(&d_sf_full_cnt,    batch_size * sizeof(int));
                cudaMalloc(&d_sf_full_bx,     batch_size * max_output_boxes * 4 * sizeof(float));
                cudaMalloc(&d_sf_full_scores, batch_size * max_output_boxes * sizeof(float));
                cudaMalloc(&d_sf_full_classes,batch_size * max_output_boxes * sizeof(int));

                // warmup
                for (int i = 0; i < WARMUP; i++) {
                    cudaMemsetAsync(d_sf_full_cnt, 0, batch_size * sizeof(int), stream);
                    cudaStreamSynchronize(stream);
                    spatialBlockNmsFull(stream, batch_size, num_boxes,
                        SF_IMAGE_SIZE, SF_OVERLAP_PX,
                        score_threshold, iou_threshold, max_output_boxes,
                        SF_GRID_X, SF_GRID_Y,
                        d_input, d_sf_full_cnt, d_sf_full_bx, d_sf_full_classes, d_sf_full_scores,
                        d_sf_blk_idx, d_sf_blk_sc, d_sf_blk_cls, d_sf_blk_start,
                        d_sf_temp_idx, d_sf_temp_sc, d_sf_temp_cl,
                        d_cub_storage, cub_bytes);
                }

                // timed
                std::vector<float> sft;
                for (int i = 0; i < ITERS; i++) {
                    float t = timeSpatialBlockFullMs(stream,
                        batch_size, num_boxes,
                        SF_IMAGE_SIZE, SF_OVERLAP_PX,
                        score_threshold, iou_threshold, max_output_boxes,
                        SF_GRID_X, SF_GRID_Y,
                        d_input, d_sf_full_cnt, d_sf_full_bx, d_sf_full_classes, d_sf_full_scores,
                        d_sf_blk_idx, d_sf_blk_sc, d_sf_blk_cls, d_sf_blk_start,
                        d_sf_temp_idx, d_sf_temp_sc, d_sf_temp_cl,
                        d_cub_storage, cub_bytes);
                    sft.push_back(t);
                }
                std::sort(sft.begin(), sft.end());
                float sf_ms = sft[ITERS / 2];

                int sf_cnt = 0;
                cudaMemcpy(&sf_cnt, d_sf_full_cnt, sizeof(int), cudaMemcpyDeviceToHost);
                auto sfdets = readDetections(sf_cnt, max_output_boxes, d_sf_full_scores, d_sf_full_bx, d_sf_full_classes);
                int sf_mismatches = countMismatches(ref_dets, sfdets);
                float sf_speedup = (sf_ms > 0.001f) ? median_t / sf_ms : 0.0f;

                std::cout << "    " << std::left << std::setw(30) << "sp 8x8 GPU Full (ext+sort+nms)"
                          << std::fixed << std::setprecision(3) << std::setw(12) << sf_ms
                          << std::setprecision(2) << std::setw(10) << sf_speedup << "x"
                          << std::setw(12) << sf_cnt;
                if (sf_mismatches == 0 && sf_cnt == ref_count)
                    std::cout << "IDENTICAL" << std::endl;
                else
                    std::cout << sf_mismatches << " diffs" << std::endl;

                // cleanup
                cudaFree(d_cub_storage);
                cudaFree(d_sf_blk_idx); cudaFree(d_sf_blk_sc); cudaFree(d_sf_blk_cls);
                cudaFree(d_sf_blk_start);
                cudaFree(d_sf_temp_idx); cudaFree(d_sf_temp_sc); cudaFree(d_sf_temp_cl);
                cudaFree(d_sf_full_cnt); cudaFree(d_sf_full_bx);
                cudaFree(d_sf_full_scores); cudaFree(d_sf_full_classes);
            }

            // 清理 spatial block GPU 临时内存
            cudaFree(d_spatial_blk_idx);
            cudaFree(d_spatial_blk_sc);
            cudaFree(d_spatial_blk_cls);
            cudaFree(d_spatial_blk_start);
            delete[] spatial_blk_idx;
            delete[] spatial_blk_sc;
            delete[] spatial_blk_cls;
            delete[] spatial_blk_start;
            delete[] spatial_blk_count;
        }

        std::cout << std::endl;

        // ---- 清理 ----
        delete[] h_input;
        delete[] h_indices;
        delete[] h_sc;
        delete[] h_cls;
        delete[] global_idx;
        delete[] global_sc;
        delete[] global_cls;

        cudaFree(d_input);
        cudaFree(d_boxes);
        cudaFree(d_scores);
        cudaFree(d_classes);
        cudaFree(d_counts);
        cudaFree(d_sorted_idx);
        cudaFree(d_sorted_sc);
        cudaFree(d_sorted_cls);
        cudaStreamDestroy(stream);

        cudaDeviceSynchronize();
    }

    // =========================================================================
    // SUMMARY TABLE (非阻塞 vs 块内排序 vs Spatial 8×8 GPU)
    // =========================================================================
    std::cout << "\n\n"
              << "================================================================================\n"
              << "  SUMMARY: Non-block vs Block(blk=100,ovlp=50) vs Spatial 8x8 GPU\n"
              << "================================================================================\n\n";

    printf(" %7s | %12s | %12s | %12s | %8s | %8s | %8s | %8s\n",
           "boxes", "non-block ms", "block ms", "spatial ms", "bl spup",
           "sp spup", "nb kept", "match");

    std::cout << std::string(105, '-') << std::endl;
    double avg_bl_speedup = 0, avg_sp_speedup = 0;
    int bl_consistent = 0, sp_consistent = 0;

    const int SUM_BLOCK = 100;
    const int SUM_OVERLAP = 50;
    const int SP_GRID_X = 8, SP_GRID_Y = 8;
    const int SP_NUM_BLOCKS = SP_GRID_X * SP_GRID_Y;
    const float SP_IMAGE_SIZE = 640.0f;
    const float SP_OVERLAP_PX = 4.0f;

    for (size_t bi = 0; bi < box_counts.size(); bi++) {
        int num_boxes = box_counts[bi];
        auto& ref = baseline_results[bi];

        const size_t input_sz = batch_size * 84 * num_boxes;
        float* h_input = new float[input_sz];
        {
            int cols = (int)std::ceil(std::sqrt((float)num_boxes));
            float cell_w = 1.0f / cols;
            for (int idx = 0; idx < num_boxes; idx++) {
                int base = idx * 84;
                int row = idx / cols;
                int col = idx % cols;
                float cx = (col + 0.5f) * cell_w;
                float cy = (row + 0.5f) * cell_w;
                float hw = cell_w * 0.45f;
                h_input[base + 0] = cx;
                h_input[base + 1] = cy;
                h_input[base + 2] = hw * 2;
                h_input[base + 3] = hw * 2;
                h_input[base + 4 + 0] = 10.0f;
                for (int c = 1; c < 80; c++)
                    h_input[base + 4 + c] = -10.0f;
            }
        }

        float *d_in, *d_bx, *d_sc;
        int *d_cl, *d_cnt, *d_si;
        float *d_ss;
        int *d_scl;
        cudaMalloc(&d_in,  input_sz * sizeof(float));
        cudaMalloc(&d_bx,  batch_size * max_output_boxes * 4 * sizeof(float));
        cudaMalloc(&d_sc,  batch_size * max_output_boxes * sizeof(float));
        cudaMalloc(&d_cl,  batch_size * max_output_boxes * sizeof(int));
        cudaMalloc(&d_cnt, batch_size * sizeof(int));
        cudaMalloc(&d_si,  batch_size * num_boxes * sizeof(int));
        cudaMalloc(&d_ss,  batch_size * num_boxes * sizeof(float));
        cudaMalloc(&d_scl, batch_size * num_boxes * sizeof(int));
        cudaMemcpy(d_in, h_input, input_sz * sizeof(float), cudaMemcpyHostToDevice);

        cudaStream_t s;
        cudaStreamCreate(&s);

        extractScores(s, batch_size, num_boxes, d_in, d_si, d_ss, d_scl);

        int* hi = new int[num_boxes];
        float* hs = new float[num_boxes];
        int* hc = new int[num_boxes];
        cudaMemcpy(hi, d_si, num_boxes * sizeof(int), cudaMemcpyDeviceToHost);
        cudaMemcpy(hs, d_ss, num_boxes * sizeof(float), cudaMemcpyDeviceToHost);
        cudaMemcpy(hc, d_scl, num_boxes * sizeof(int), cudaMemcpyDeviceToHost);

        // ---- Block NMS (blk=100, ovlp=50) ----
        int* blk_idx = new int[num_boxes];
        float* blk_sc = new float[num_boxes];
        int* blk_cls = new int[num_boxes];
        buildBlockSorted(num_boxes, SUM_BLOCK, hi, hs, hc, blk_idx, blk_sc, blk_cls);

        cudaMemcpy(d_si, blk_idx, num_boxes * sizeof(int), cudaMemcpyHostToDevice);
        cudaMemcpy(d_ss, blk_sc,  num_boxes * sizeof(float), cudaMemcpyHostToDevice);
        cudaMemcpy(d_scl, blk_cls, num_boxes * sizeof(int), cudaMemcpyHostToDevice);

        delete[] blk_idx; delete[] blk_sc; delete[] blk_cls;

        for (int i = 0; i < WARMUP; i++) {
            cudaMemsetAsync(d_cnt, 0, batch_size * sizeof(int), s);
            cudaStreamSynchronize(s);
            blockNmsKernelOnly(s, batch_size, num_boxes,
                               score_threshold, iou_threshold, max_output_boxes,
                               SUM_BLOCK, SUM_OVERLAP,
                               d_in, d_cnt, d_bx, d_cl, d_sc,
                               d_si, d_ss, d_scl);
        }

        std::vector<float> btt;
        for (int i = 0; i < ITERS; i++) {
            float bt = timeBlockMs(s, SUM_BLOCK, SUM_OVERLAP,
                batch_size, num_boxes,
                score_threshold, iou_threshold, max_output_boxes,
                d_in, d_cnt, d_bx, d_cl, d_sc,
                d_si, d_ss, d_scl);
            btt.push_back(bt);
        }
        std::sort(btt.begin(), btt.end());
        float block_t = btt[ITERS / 2];

        int bc = 0;
        cudaMemcpy(&bc, d_cnt, sizeof(int), cudaMemcpyDeviceToHost);
        auto bd = readDetections(bc, max_output_boxes, d_sc, d_bx, d_cl);
        int bl_mm = countMismatches(ref.dets, bd);
        float bl_sp = (block_t > 0.001f) ? ref.time_ms / block_t : 0.0f;
        avg_bl_speedup += bl_sp;
        if (bl_mm == 0 && bc == ref.detections) bl_consistent++;

        // ---- Spatial 8x8 GPU NMS ----
        int* sp_idx = new int[num_boxes];
        float* sp_sc = new float[num_boxes];
        int* sp_cls = new int[num_boxes];
        int* sp_start = new int[SP_NUM_BLOCKS + 1];
        int* sp_count = new int[SP_NUM_BLOCKS];
        buildSpatialBlockSorted(num_boxes, SP_GRID_X, SP_GRID_Y,
                                SP_IMAGE_SIZE, SP_OVERLAP_PX,
                                h_input, hi, hs, hc,
                                sp_idx, sp_sc, sp_cls,
                                sp_start, sp_count);

        int* d_sp_idx;
        float* d_sp_sc;
        int* d_sp_cls;
        int* d_sp_start;
        float* d_sp_bx;
        float* d_sp_scores;
        int* d_sp_classes;
        int* d_sp_cnt;
        cudaMalloc(&d_sp_idx,   batch_size * num_boxes * sizeof(int));
        cudaMalloc(&d_sp_sc,    batch_size * num_boxes * sizeof(float));
        cudaMalloc(&d_sp_cls,   batch_size * num_boxes * sizeof(int));
        cudaMalloc(&d_sp_start, batch_size * (SP_NUM_BLOCKS + 1) * sizeof(int));
        cudaMalloc(&d_sp_bx,     batch_size * max_output_boxes * 4 * sizeof(float));
        cudaMalloc(&d_sp_scores, batch_size * max_output_boxes * sizeof(float));
        cudaMalloc(&d_sp_classes,batch_size * max_output_boxes * sizeof(int));
        cudaMalloc(&d_sp_cnt,    batch_size * sizeof(int));
        cudaMemcpy(d_sp_idx,   sp_idx,   num_boxes * sizeof(int), cudaMemcpyHostToDevice);
        cudaMemcpy(d_sp_sc,    sp_sc,    num_boxes * sizeof(float), cudaMemcpyHostToDevice);
        cudaMemcpy(d_sp_cls,   sp_cls,   num_boxes * sizeof(int), cudaMemcpyHostToDevice);
        cudaMemcpy(d_sp_start, sp_start, (SP_NUM_BLOCKS + 1) * sizeof(int), cudaMemcpyHostToDevice);
        // sp_count (64 ints) not needed on GPU; d_sp_cnt is output_counts (1 int per batch)
        delete[] sp_count;

        for (int i = 0; i < WARMUP; i++) {
            cudaMemsetAsync(d_sp_cnt, 0, batch_size * sizeof(int), s);
            cudaStreamSynchronize(s);
            spatialBlockNmsKernelOnly(s, batch_size, num_boxes,
                SP_IMAGE_SIZE, SP_OVERLAP_PX,
                score_threshold, iou_threshold, max_output_boxes,
                SP_GRID_X, SP_GRID_Y,
                d_in, d_sp_cnt, d_sp_bx, d_sp_classes, d_sp_scores,
                d_sp_idx, d_sp_sc, d_sp_cls, d_sp_start);
        }

        std::vector<float> spt;
        for (int i = 0; i < ITERS; i++) {
            float t = timeSpatialBlockMs(s,
                batch_size, num_boxes,
                SP_IMAGE_SIZE, SP_OVERLAP_PX,
                score_threshold, iou_threshold, max_output_boxes,
                SP_GRID_X, SP_GRID_Y,
                d_in, d_sp_cnt, d_sp_bx, d_sp_classes, d_sp_scores,
                d_sp_idx, d_sp_sc, d_sp_cls, d_sp_start);
            spt.push_back(t);
        }
        std::sort(spt.begin(), spt.end());
        float spatial_t = spt[ITERS / 2];

        int spc = 0;
        cudaMemcpy(&spc, d_sp_cnt, sizeof(int), cudaMemcpyDeviceToHost);
        auto spd = readDetections(spc, max_output_boxes, d_sp_scores, d_sp_bx, d_sp_classes);
        int sp_mm = countMismatches(ref.dets, spd);
        float sp_su = (spatial_t > 0.001f) ? ref.time_ms / spatial_t : 0.0f;
        avg_sp_speedup += sp_su;
        if (sp_mm == 0 && spc == ref.detections) sp_consistent++;

        // 综合 match 状态
        std::string match_str = "OK";
        if (bl_mm != 0 || sp_mm != 0 || bc != ref.detections || spc != ref.detections) {
            match_str = "!=";
        }

        printf(" %7d | %12.3f | %12.3f | %12.3f | %7.2fx | %7.2fx | %8d | %8s\n",
               num_boxes, ref.time_ms, block_t, spatial_t, bl_sp, sp_su,
               ref.detections, match_str.c_str());

        delete[] h_input; delete[] hi; delete[] hs; delete[] hc;

        cudaFree(d_in); cudaFree(d_bx); cudaFree(d_sc);
        cudaFree(d_cl); cudaFree(d_cnt);
        cudaFree(d_si); cudaFree(d_ss); cudaFree(d_scl);
        cudaFree(d_sp_idx); cudaFree(d_sp_sc); cudaFree(d_sp_cls);
        cudaFree(d_sp_start);
        cudaFree(d_sp_bx); cudaFree(d_sp_scores); cudaFree(d_sp_classes);
        cudaFree(d_sp_cnt);
        cudaStreamDestroy(s);
    }

    avg_bl_speedup /= box_counts.size();
    avg_sp_speedup /= box_counts.size();
    std::cout << std::string(105, '-') << std::endl;
    printf(" Block avg speedup: %.2fx   Spatial avg speedup: %.2fx\n",
           avg_bl_speedup, avg_sp_speedup);
    printf(" Block consistency: %d/%d   Spatial consistency: %d/%d\n",
           bl_consistent, (int)box_counts.size(),
           sp_consistent, (int)box_counts.size());
    std::cout << std::string(105, '=') << std::endl;

    // =========================================================================
    // 结论
    // =========================================================================
    std::cout << "\nCONCLUSION:\n";
    std::cout << "  - Non-block: global sort + full O(N^2) comparison (guarantees correct)\n";
    std::cout << "  - Block:     block-local sort + limited-range scan (approximation)\n";
    std::cout << "  - Spatial:   8x8 coordinate-based spatial partition + GPU per-block fast NMS\n";
    std::cout << "  - Block method avoids global sort and limits comparison scope\n";
    std::cout << "  - Spatial method further reduces scope via coordinate binning\n";
    std::cout << std::endl;

    return 0;
}