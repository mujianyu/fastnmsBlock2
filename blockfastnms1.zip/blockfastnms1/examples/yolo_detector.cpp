#include <iostream>
#include <vector>
#include <cstring>
#include <cuda_runtime.h>
#include <NvInfer.h>
#include <NvInferRuntime.h>
#include <algorithm>

// Logger for TensorRT
class Logger : public nvinfer1::ILogger {
public:
    void log(Severity severity, const char* msg) noexcept override {
        if (severity != Severity::kINFO) {
            std::cout << "[" << static_cast<int>(severity) << "] " << msg << std::endl;
        }
    }
} gLogger;

// Simple YOLO detector implementation
class YOLODetector {
public:
    struct Detection {
        float x, y, w, h;
        int class_id;
        float confidence;
    };
    
    YOLODetector(int batch_size = 1, int max_detections = 1000)
        : batch_size_(batch_size), max_detections_(max_detections),
          num_boxes_(8400), feature_size_(84) {
    }
    
    ~YOLODetector() {
        cleanup();
    }
    
    void initialize() {
        // Allocate GPU memory for inference
        const size_t input_size = batch_size_ * feature_size_ * num_boxes_;
        const size_t output_size = batch_size_ * max_detections_;
        
        cudaMalloc(&d_input_data_, input_size * sizeof(float));
        cudaMalloc(&d_output_boxes_, output_size * 4 * sizeof(float));
        cudaMalloc(&d_output_scores_, output_size * sizeof(float));
        cudaMalloc(&d_output_indices_, output_size * sizeof(int));
        cudaMalloc(&d_output_counts_, batch_size_ * sizeof(int));
        
        // Host memory
        h_input_data_ = new float[input_size];
        h_output_boxes_ = new float[output_size * 4];
        h_output_scores_ = new float[output_size];
        h_output_indices_ = new int[output_size];
        h_output_counts_ = new int[batch_size_];
    }
    
    void processData(const float* input_data) {
        const size_t input_size = batch_size_ * feature_size_ * num_boxes_;
        std::memcpy(h_input_data_, input_data, input_size * sizeof(float));
        
        // Copy to GPU
        cudaMemcpy(d_input_data_, h_input_data_, 
                  input_size * sizeof(float), cudaMemcpyHostToDevice);
    }
    
    std::vector<Detection> getDetections(int batch_idx = 0) {
        const size_t output_size = batch_size_ * max_detections_;
        
        // Copy results from GPU
        cudaMemcpy(h_output_boxes_, d_output_boxes_, 
                  output_size * 4 * sizeof(float), cudaMemcpyDeviceToHost);
        cudaMemcpy(h_output_scores_, d_output_scores_, 
                  output_size * sizeof(float), cudaMemcpyDeviceToHost);
        cudaMemcpy(h_output_counts_, d_output_counts_, 
                  batch_size_ * sizeof(int), cudaMemcpyDeviceToHost);
        
        // Extract detections
        std::vector<Detection> detections;
        int count = h_output_counts_[batch_idx];
        
        for (int i = 0; i < count && i < max_detections_; i++) {
            int idx = batch_idx * max_detections_ + i;
            Detection det;
            det.x = h_output_boxes_[idx * 4 + 0];
            det.y = h_output_boxes_[idx * 4 + 1];
            det.w = h_output_boxes_[idx * 4 + 2];
            det.h = h_output_boxes_[idx * 4 + 3];
            det.confidence = h_output_scores_[idx];
            det.class_id = 0; // Would need separate class output
            
            detections.push_back(det);
        }
        
        return detections;
    }
    
    void printDetections(const std::vector<Detection>& detections) {
        std::cout << "\nDetections (" << detections.size() << " found):" << std::endl;
        std::cout << std::string(70, '=') << std::endl;
        std::cout << "Index | X\t\t| Y\t\t| W\t\t| H\t\t| Class | Conf" << std::endl;
        std::cout << std::string(70, '-') << std::endl;
        
        for (size_t i = 0; i < std::min(size_t(10), detections.size()); i++) {
            const auto& det = detections[i];
            std::cout << i << "\t| " 
                     << det.x << "\t| "
                     << det.y << "\t| "
                     << det.w << "\t| "
                     << det.h << "\t| "
                     << det.class_id << "\t| "
                     << det.confidence << std::endl;
        }
        
        if (detections.size() > 10) {
            std::cout << "... and " << (detections.size() - 10) << " more" << std::endl;
        }
    }
    
    float* getDeviceInputBuffer() { return d_input_data_; }
    float* getDeviceOutputBoxes() { return d_output_boxes_; }
    float* getDeviceOutputScores() { return d_output_scores_; }
    int* getDeviceOutputIndices() { return d_output_indices_; }
    int* getDeviceOutputCounts() { return d_output_counts_; }
    
private:
    void cleanup() {
        if (d_input_data_) cudaFree(d_input_data_);
        if (d_output_boxes_) cudaFree(d_output_boxes_);
        if (d_output_scores_) cudaFree(d_output_scores_);
        if (d_output_indices_) cudaFree(d_output_indices_);
        if (d_output_counts_) cudaFree(d_output_counts_);
        
        if (h_input_data_) delete[] h_input_data_;
        if (h_output_boxes_) delete[] h_output_boxes_;
        if (h_output_scores_) delete[] h_output_scores_;
        if (h_output_indices_) delete[] h_output_indices_;
        if (h_output_counts_) delete[] h_output_counts_;
    }
    
    int batch_size_;
    int max_detections_;
    int num_boxes_;
    int feature_size_;
    
    // GPU memory
    float* d_input_data_ = nullptr;
    float* d_output_boxes_ = nullptr;
    float* d_output_scores_ = nullptr;
    int* d_output_indices_ = nullptr;
    int* d_output_counts_ = nullptr;
    
    // Host memory
    float* h_input_data_ = nullptr;
    float* h_output_boxes_ = nullptr;
    float* h_output_scores_ = nullptr;
    int* h_output_indices_ = nullptr;
    int* h_output_counts_ = nullptr;
};

int main() {
    std::cout << "Block-FastNMS YOLO Detector Example" << std::endl;
    std::cout << "===================================" << std::endl;
    std::cout << std::endl;
    
    try {
        // Initialize detector
        std::cout << "Initializing detector..." << std::endl;
        YOLODetector detector(1, 1000);
        detector.initialize();
        std::cout << "✓ Detector initialized" << std::endl;
        std::cout << std::endl;
        
        // Create dummy input data
        std::cout << "Generating test data..." << std::endl;
        const size_t input_size = 1 * 84 * 8400;
        float* test_input = new float[input_size];
        
        // Generate random test data
        for (size_t i = 0; i < input_size; i++) {
            test_input[i] = static_cast<float>(rand()) / RAND_MAX * 10 - 5;
        }
        std::cout << "✓ Test data generated (" << input_size << " values)" << std::endl;
        std::cout << std::endl;
        
        // Process data
        std::cout << "Processing data..." << std::endl;
        detector.processData(test_input);
        std::cout << "✓ Data processed" << std::endl;
        std::cout << std::endl;
        
        // Get detections
        std::cout << "Retrieving detections..." << std::endl;
        auto detections = detector.getDetections(0);
        std::cout << "✓ " << detections.size() << " detections retrieved" << std::endl;
        std::cout << std::endl;
        
        // Print detections
        detector.printDetections(detections);
        
        // Statistics
        std::cout << std::endl;
        std::cout << "Detection Statistics:" << std::endl;
        std::cout << std::string(40, '-') << std::endl;
        
        float total_conf = 0;
        for (const auto& det : detections) {
            total_conf += det.confidence;
        }
        
        if (detections.size() > 0) {
            std::cout << "Average Confidence: " << (total_conf / detections.size()) << std::endl;
        }
        
        std::cout << "Total Detections: " << detections.size() << std::endl;
        std::cout << std::endl;
        
        // Cleanup
        delete[] test_input;
        
        std::cout << "Example completed successfully!" << std::endl;
        return 0;
        
    } catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << std::endl;
        return 1;
    }
}
