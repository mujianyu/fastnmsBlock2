#!/bin/bash

# Build and Test Script for Block-FastNMS TensorRT Plugin

set -e

echo "═══════════════════════════════════════════════════════════════"
echo "Block-FastNMS TensorRT Plugin - Build and Test"
echo "═══════════════════════════════════════════════════════════════"
echo ""

# Colors for output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Step 1: Configure
echo -e "${BLUE}Step 1: Configuring with CMake...${NC}"
if [ ! -d "build" ]; then
    mkdir -p build
fi
cd build
cmake -DCMAKE_BUILD_TYPE=Release .. > /dev/null 2>&1
echo -e "${GREEN}✓ CMake configuration completed${NC}"
echo ""

# Step 2: Build
echo -e "${BLUE}Step 2: Building plugin and test executable...${NC}"
make -j$(nproc) > /dev/null 2>&1
echo -e "${GREEN}✓ Build completed successfully${NC}"
echo ""

# Step 3: Verify build artifacts
echo -e "${BLUE}Step 3: Verifying build artifacts...${NC}"
if [ -f "lib/libblock_fastnms_plugin.so" ]; then
    echo -e "${GREEN}✓ Plugin library:${NC} $(du -h lib/libblock_fastnms_plugin.so | cut -f1)"
else
    echo -e "${YELLOW}✗ Plugin library not found${NC}"
    exit 1
fi

if [ -f "bin/test_inference" ]; then
    echo -e "${GREEN}✓ Test executable:${NC} $(du -h bin/test_inference | cut -f1)"
else
    echo -e "${YELLOW}✗ Test executable not found${NC}"
    exit 1
fi
echo ""

# Step 4: Show information
echo -e "${BLUE}Step 4: Build Information${NC}"
echo -e "${GREEN}Plugin Name:${NC} BlockFastNMS v1.0"
echo -e "${GREEN}Input Shape:${NC} [B, 84, 8400]"
echo -e "${GREEN}Output Shape:${NC} [B, M, 6] where M=1000"
echo -e "${GREEN}Score Threshold:${NC} 0.25"
echo -e "${GREEN}IoU Threshold:${NC} 0.7"
echo ""

echo -e "${BLUE}Build artifacts location:${NC}"
echo "  Plugin:    $(pwd)/lib/libblock_fastnms_plugin.so"
echo "  Test:      $(pwd)/bin/test_inference"
echo ""

cd ..

echo "═══════════════════════════════════════════════════════════════"
echo -e "${GREEN}Build completed successfully!${NC}"
echo "═══════════════════════════════════════════════════════════════"
echo ""

echo "Next steps:"
echo "1. To run the test:"
echo "   ./build/bin/test_inference"
echo ""
echo "2. To integrate the plugin in TensorRT:"
echo "   - Copy libblock_fastnms_plugin.so to your plugin search path"
echo "   - Load plugin in your application:"
echo ""
echo "3. Usage in Python/C++:"
echo "   - See examples in examples/ directory"
echo "   - See detailed usage in README.md"
